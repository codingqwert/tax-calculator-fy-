# Indian Tax Calculator - Budget 2025 Updates

## Overview
All tax calculations have been updated to reflect Union Budget 2025 (FY 2025-26, AY 2026-27) as per Finance Act 2025.

---

## 1. INCOME TAX CHANGES

### New Tax Regime (Default Regime)
**Tax Slabs Updated:**

| Income Range | Tax Rate | Previous (2024-25) |
|--------------|----------|-------------------|
| ₹0 - ₹4,00,000 | 0% | ₹0 - ₹3,00,000 |
| ₹4,00,001 - ₹8,00,000 | 5% | ₹3,00,001 - ₹7,00,000 |
| ₹8,00,001 - ₹12,00,000 | 10% | ₹7,00,001 - ₹10,00,000 |
| ₹12,00,001 - ₹16,00,000 | 15% | ₹10,00,001 - ₹12,00,000 |
| ₹16,00,001 - ₹20,00,000 | 20% | ₹12,00,001 - ₹15,00,000 |
| ₹20,00,001 - ₹24,00,000 | 25% | ₹15,00,001+ at 30% |
| Above ₹24,00,000 | 30% | (New bracket) |

**Section 87A Rebate - MAJOR CHANGE:**
- **Old:** Up to ₹25,000 rebate for income up to ₹7,00,000
- **NEW:** Up to ₹60,000 rebate for income up to ₹12,00,000

**Effective Tax-Free Income:**
- With ₹75,000 standard deduction + ₹60,000 rebate
- **No tax up to ₹12,75,000 gross income**

### Old Tax Regime (Opt-in Required)
- Unchanged from previous year
- Standard deduction: ₹50,000
- Section 87A rebate: ₹12,500 for income up to ₹5,00,000

---

## 2. CAPITAL GAINS TAX CHANGES

### Short-Term Capital Gains (STCG)
| Asset Type | Holding Period | Tax Rate | Status |
|-----------|----------------|----------|--------|
| Listed Equity/MF (STT paid) | <12 months | **20%** | **Increased from 15%** |
| Other Assets | <24 months | As per slab | Unchanged |

### Long-Term Capital Gains (LTCG)
| Asset Type | Holding Period | Tax Rate | Exemption | Status |
|-----------|----------------|----------|-----------|--------|
| Listed Equity/MF | ≥12 months | 12.5% | ₹1,25,000 | Unchanged |
| Property/Real Estate | ≥24 months | 12.5% | None | **Indexation removed** |
| Gold/Debt Funds | ≥24 months | 12.5% | None | **Indexation removed** |

**IMPORTANT:** Indexation benefit removed for assets purchased on or after **July 23, 2024**

---

## 3. TDS RATE CHANGES

### Updated Thresholds

| Section | Type | Rate | Threshold | Change |
|---------|------|------|-----------|--------|
| 194-I | Rent | 10% | ₹6,00,000/year (₹50k/month) | **Increased from ₹2,40,000** |
| 194-J | Professional Fees | 10% | ₹30,000 | Unchanged |
| 194-C | Contractor | 1%-2% | ₹30,000 | Unchanged |
| 194-H | Commission | 5% | ₹15,000 | Unchanged |
| 194-A | Interest | 10% | ₹40,000 | Unchanged |
| 194 | Dividend | 10% | ₹5,000 | Unchanged |
| 194-B | Lottery | 30% | ₹10,000 | Unchanged |

### Salary TDS
- No TDS for taxable income up to ₹12,00,000 (with 87A rebate)
- Slabs aligned with new tax regime

---

## 4. STANDARD DEDUCTION

| Regime | Amount | Status |
|--------|--------|--------|
| New Regime | ₹75,000 | Unchanged |
| Old Regime | ₹50,000 | Unchanged |

---

## 5. DEDUCTION LIMITS (Old Regime Only)

All deduction limits remain unchanged:
- Section 80C: ₹1,50,000
- Section 80CCD(1B): ₹50,000 (NPS additional)
- Section 80D: ₹25,000 (self), ₹50,000 (senior citizen)
- Section 80D: ₹25,000 (parents), ₹50,000 (parents senior)
- Section 24: ₹2,00,000 (home loan interest)
- Section 80E: No limit (education loan)
- Section 80G: Donation-based

---

## 6. SURCHARGE & CESS

**Unchanged:**
- Surcharge: 10% (₹50L-₹1Cr), 15% (₹1Cr-₹2Cr), 25% (₹2Cr-₹5Cr), 37% (>₹5Cr)
- Health & Education Cess: 4% on (tax + surcharge)

---

## 7. DOCUMENT ANALYSIS FEATURE

### AI-Powered Tax Calculation from Documents
- Upload bank statements, Form 16, investment proofs, receipts
- Gemini 2.0 Flash extracts income, deductions, investments, TDS paid
- Automatic categorization into tax sections
- Instant tax calculation with both regime comparison
- Personalized tax-saving recommendations

**Supported Formats:**
- PDF, JPG, PNG, XLSX, CSV
- Multiple documents simultaneously
- Up to 10MB per file

---

## 8. KEY HIGHLIGHTS FOR TAXPAYERS

### Middle-Class Relief
1. **₹12 lakh tax-free:** Biggest relief for salaried individuals
2. **Simplified slabs:** 7 slabs instead of 6, better progression
3. **Higher rebate:** ₹60,000 rebate vs previous ₹25,000

### Investors
1. **STCG increased:** Equity STCG now 20% (from 15%)
2. **Indexation removed:** Property/gold LTCG simplified to 12.5%
3. **Uniform LTCG:** All assets at 12.5% for simplification

### Rent Payers
1. **Higher TDS threshold:** ₹50,000/month (was ₹20,000)
2. **Less compliance burden:** Fewer TDS deductions

---

## 9. IMPLEMENTATION STATUS

### Backend Updates ✅
- ✅ Income tax slabs updated in `income_tax_service.py`
- ✅ Section 87A rebate increased to ₹60,000
- ✅ Capital gains rates updated in `capital_gains_service.py`
- ✅ Indexation benefit removed for new assets
- ✅ TDS rates and thresholds updated in `tds_service.py`
- ✅ Salary TDS calculation aligned with new slabs

### Frontend Updates ✅
- ✅ Tax slabs updated in `mock.js`
- ✅ Title changed to "2025-26"
- ✅ Rebate amounts updated
- ✅ Capital gains UI updated (indexation removed)
- ✅ Disclaimer updated with Budget 2025 info
- ✅ All calculations tested and verified

### API Testing ✅
- ✅ Income tax calculation: ₹12L income = ₹0 tax
- ✅ Capital gains: STCG @ 20%, LTCG @ 12.5%
- ✅ TDS calculations with new thresholds
- ✅ Regime comparison working correctly

---

## 10. VERIFICATION CHECKLIST

- [x] Tax slabs match Budget 2025 announcement
- [x] Section 87A rebate: ₹60,000 for ≤₹12L income
- [x] STCG equity: 20%
- [x] LTCG equity: 12.5% above ₹1.25L
- [x] LTCG other: 12.5% without indexation
- [x] TDS rent threshold: ₹6,00,000/year
- [x] Standard deduction: ₹75,000 (new), ₹50,000 (old)
- [x] Surcharge and cess: Unchanged at 4%
- [x] All APIs return correct calculations
- [x] Frontend displays Budget 2025 information

---

## 11. COMPARISON: 2024-25 vs 2025-26

### Example: ₹10 Lakh Income

**AY 2025-26 (Old):**
- Standard deduction: ₹75,000
- Taxable: ₹9,25,000
- Tax: ₹67,500
- Rebate: ₹25,000 (not applicable, income > ₹7L)
- **Final Tax: ₹67,500 + cess = ₹70,200**

**AY 2026-27 (Budget 2025):**
- Standard deduction: ₹75,000
- Taxable: ₹9,25,000
- Tax: ₹42,500
- Rebate: ₹42,500 (income < ₹12L, eligible)
- **Final Tax: ₹0**

**Savings: ₹70,200 per year!**

---

## 12. RESOURCES & REFERENCES

1. Union Budget 2025 Speech
2. Finance Act 2025
3. Income Tax Act, 1961 (as amended)
4. Official Income Tax Department notifications
5. Ministry of Finance press releases

---

## 13. FUTURE UPDATES

The calculator will be updated as:
- Clarifications issued by CBDT
- New circulars or notifications
- Any amendments to Finance Act 2025

---

**Last Updated:** Based on Union Budget 2025 presented on Feb 1, 2025
**Applicable For:** Financial Year 2025-26 (Assessment Year 2026-27)

---

## Developer Notes

### Files Updated:
1. `/app/backend/services/income_tax_service.py`
2. `/app/backend/services/capital_gains_service.py`
3. `/app/backend/services/tds_service.py`
4. `/app/frontend/src/mock.js`
5. `/app/frontend/src/pages/TaxCalculator.jsx`
6. `/app/frontend/src/components/CapitalGainsCalculator.jsx`

### Testing:
```bash
# Test income tax (₹12L should be tax-free)
curl -X POST http://localhost:8001/api/calculate-income-tax \
  -H "Content-Type: application/json" \
  -d '{"income":{"salary":1200000,"business":0,"other":0},"deductions":{...},"regime":"new"}'

# Test capital gains (STCG @ 20%)
curl -X POST http://localhost:8001/api/calculate-capital-gains \
  -H "Content-Type: application/json" \
  -d '{"assetType":"equity","holdingPeriod":"short","purchasePrice":100000,"salePrice":150000}'
```
