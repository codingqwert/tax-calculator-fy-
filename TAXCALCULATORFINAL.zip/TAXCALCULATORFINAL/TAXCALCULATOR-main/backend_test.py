#!/usr/bin/env python3
"""
Comprehensive Backend API Tests for Indian Tax Calculator
Tests all tax calculation APIs and validates responses
"""

import requests
import json
import sys
from datetime import datetime
from typing import Dict, Any

# Backend URL from environment
BACKEND_URL = "#!/usr/bin/env python3
"""
Comprehensive Backend API Tests for Indian Tax Calculator
Tests all tax calculation APIs and validates responses
"""

import requests
import json
import sys
from datetime import datetime
from typing import Dict, Any

# Backend URL from environment
BACKEND_URL = "#!/usr/bin/env python3
"""
Comprehensive Backend API Tests for Indian Tax Calculator
Tests all tax calculation APIs and validates responses
"""

import requests
import json
import sys
from datetime import datetime
from typing import Dict, Any

# Backend URL from environment
BACKEND_URL = "http://localhost:8000"

class TaxCalculatorTester:
    def __init__(self):
        self.test_results = []
        self.failed_tests = []
        
    def log_test(self, test_name: str, success: bool, details: str = ""):
        """Log test results"""
        status = "✅ PASS" if success else "❌ FAIL"
        result = f"{status} - {test_name}"
        if details:
            result += f": {details}"
        
        self.test_results.append(result)
        if not success:
            self.failed_tests.append(f"{test_name}: {details}")
        print(result)
    
    def test_income_tax_new_regime(self):
        """Test income tax calculation for new regime"""
        test_name = "Income Tax - New Regime (Salary: 15L, Business: 3L)"
        
        payload = {
            "income": {
                "salary": 1500000,
                "business": 300000,
                "other": 0
            },
            "deductions": {
                "section80C": 0,
                "section80CCD1B": 0,
                "section80D": 0,
                "section80DParents": 0,
                "hra": 0,
                "homeLoan": 0,
                "section80E": 0,
                "section80G": 0
            },
            "regime": "new"
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-income-tax", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            
            if not data.get('success'):
                self.log_test(test_name, False, f"API returned success=false: {data}")
                return
            
            result = data.get('data', {})
            
            # Validate response structure
            required_fields = ['grossIncome', 'taxableIncome', 'baseTax', 'totalTax', 'effectiveRate']
            missing_fields = [field for field in required_fields if field not in result]
            
            if missing_fields:
                self.log_test(test_name, False, f"Missing fields: {missing_fields}")
                return
            
            # Validate calculations for new regime
            expected_gross = 1800000  # 15L + 3L
            expected_taxable = 1725000  # Gross - 75K standard deduction
            
            if result['grossIncome'] != expected_gross:
                self.log_test(test_name, False, f"Gross income mismatch: expected {expected_gross}, got {result['grossIncome']}")
                return
            
            if result['taxableIncome'] != expected_taxable:
                self.log_test(test_name, False, f"Taxable income mismatch: expected {expected_taxable}, got {result['taxableIncome']}")
                return
            
            # Check if tax is calculated (should be > 0 for this income)
            if result['totalTax'] <= 0:
                self.log_test(test_name, False, f"Total tax should be > 0 for income 18L, got {result['totalTax']}")
                return
            
            self.log_test(test_name, True, f"Tax: ₹{result['totalTax']:,}, Rate: {result['effectiveRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_income_tax_old_regime_with_deductions(self):
        """Test income tax calculation for old regime with deductions"""
        test_name = "Income Tax - Old Regime with Deductions"
        
        payload = {
            "income": {
                "salary": 1200000,
                "business": 0,
                "other": 0
            },
            "deductions": {
                "section80C": 150000,
                "section80CCD1B": 50000,
                "section80D": 25000,
                "section80DParents": 0,
                "hra": 200000,
                "homeLoan": 100000,
                "section80E": 0,
                "section80G": 0
            },
            "regime": "old"
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-income-tax", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Validate deductions are applied in old regime
            total_deductions = 150000 + 50000 + 25000 + 200000 + 100000 + 50000  # Including standard deduction
            expected_taxable = 1200000 - total_deductions
            
            if result['taxableIncome'] != max(0, expected_taxable):
                self.log_test(test_name, False, f"Deductions not applied correctly in old regime")
                return
            
            self.log_test(test_name, True, f"Deductions applied: ₹{result['deductions']:,}")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_regime_comparison(self):
        """Test regime comparison API"""
        test_name = "Regime Comparison"
        
        payload = {
            "income": {
                "salary": 1000000,
                "business": 0,
                "other": 0
            },
            "deductions": {
                "section80C": 150000,
                "section80CCD1B": 0,
                "section80D": 25000,
                "section80DParents": 0,
                "hra": 100000,
                "homeLoan": 0,
                "section80E": 0,
                "section80G": 0
            },
            "regime": "new"
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/compare-regimes", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Validate comparison structure
            required_fields = ['new_regime', 'old_regime', 'savings', 'recommended']
            missing_fields = [field for field in required_fields if field not in result]
            
            if missing_fields:
                self.log_test(test_name, False, f"Missing fields: {missing_fields}")
                return
            
            # Check if both regime calculations exist
            if 'totalTax' not in result['new_regime'] or 'totalTax' not in result['old_regime']:
                self.log_test(test_name, False, "Missing tax calculations in regime comparison")
                return
            
            new_tax = result['new_regime']['totalTax']
            old_tax = result['old_regime']['totalTax']
            savings = result['savings']
            
            self.log_test(test_name, True, f"New: ₹{new_tax:,}, Old: ₹{old_tax:,}, Savings: ₹{savings:,}, Recommended: {result['recommended']}")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_capital_gains_equity_ltcg(self):
        """Test equity LTCG calculation"""
        test_name = "Capital Gains - Equity LTCG"
        
        payload = {
            "assetType": "equity",
            "holdingPeriod": "long",
            "purchasePrice": 500000,
            "salePrice": 1200000,
            "indexation": False
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-capital-gains", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Validate response structure
            required_fields = ['gains', 'exemptionAmount', 'taxableGain', 'taxRate', 'totalTax']
            missing_fields = [field for field in required_fields if field not in result]
            
            if missing_fields:
                self.log_test(test_name, False, f"Missing fields: {missing_fields}")
                return
            
            # Validate calculations
            expected_gains = 700000  # 12L - 5L
            expected_exemption = 125000  # LTCG equity exemption
            expected_taxable = 575000  # 7L - 1.25L
            expected_rate = 12.5  # LTCG equity rate
            
            if result['gains'] != expected_gains:
                self.log_test(test_name, False, f"Gains calculation error: expected {expected_gains}, got {result['gains']}")
                return
            
            if result['exemptionAmount'] != expected_exemption:
                self.log_test(test_name, False, f"Exemption error: expected {expected_exemption}, got {result['exemptionAmount']}")
                return
            
            if result['taxRate'] != expected_rate:
                self.log_test(test_name, False, f"Tax rate error: expected {expected_rate}%, got {result['taxRate']}%")
                return
            
            self.log_test(test_name, True, f"Gains: ₹{result['gains']:,}, Tax: ₹{result['totalTax']:,} at {result['taxRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_capital_gains_equity_stcg(self):
        """Test equity STCG calculation"""
        test_name = "Capital Gains - Equity STCG"
        
        payload = {
            "assetType": "equity",
            "holdingPeriod": "short",
            "purchasePrice": 300000,
            "salePrice": 400000,
            "indexation": False
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-capital-gains", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Validate STCG equity calculations
            expected_gains = 100000
            expected_rate = 20  # STCG equity rate
            
            if result['gains'] != expected_gains:
                self.log_test(test_name, False, f"Gains calculation error")
                return
            
            if result['taxRate'] != expected_rate:
                self.log_test(test_name, False, f"STCG rate should be 20%, got {result['taxRate']}%")
                return
            
            # No exemption for STCG
            if result['exemptionAmount'] != 0:
                self.log_test(test_name, False, f"STCG should have no exemption, got {result['exemptionAmount']}")
                return
            
            self.log_test(test_name, True, f"STCG Tax: ₹{result['totalTax']:,} at {result['taxRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_capital_gains_other_assets_with_indexation(self):
        """Test other assets LTCG with indexation"""
        test_name = "Capital Gains - Other Assets with Indexation"
        
        payload = {
            "assetType": "property",
            "holdingPeriod": "long",
            "purchasePrice": 2000000,
            "salePrice": 3500000,
            "indexation": True
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-capital-gains", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Validate other assets LTCG with indexation
            expected_rate = 20  # LTCG other assets with indexation
            
            if result['taxRate'] != expected_rate:
                self.log_test(test_name, False, f"LTCG with indexation rate should be 20%, got {result['taxRate']}%")
                return
            
            self.log_test(test_name, True, f"LTCG with indexation: ₹{result['totalTax']:,} at {result['taxRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_tds_salary(self):
        """Test salary TDS calculation"""
        test_name = "TDS - Salary"
        
        payload = {
            "tdsType": "salary",
            "amount": 100000,  # Monthly salary
            "panAvailable": True,
            "taxableIncome": 1200000  # Annual income
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-tds", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Validate TDS structure
            required_fields = ['amount', 'tdsRate', 'tdsAmount', 'netAmount', 'applicable']
            missing_fields = [field for field in required_fields if field not in result]
            
            if missing_fields:
                self.log_test(test_name, False, f"Missing fields: {missing_fields}")
                return
            
            # For 12L annual income, TDS rate should be 15% (new regime slab)
            if result['tdsRate'] != 15:
                self.log_test(test_name, False, f"TDS rate for 12L income should be 15%, got {result['tdsRate']}%")
                return
            
            expected_tds = 15000  # 15% of 1L
            if result['tdsAmount'] != expected_tds:
                self.log_test(test_name, False, f"TDS amount calculation error: expected {expected_tds}, got {result['tdsAmount']}")
                return
            
            self.log_test(test_name, True, f"Salary TDS: ₹{result['tdsAmount']:,} at {result['tdsRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_tds_rent_194i(self):
        """Test rent TDS (194I) calculation"""
        test_name = "TDS - Rent (194I)"
        
        payload = {
            "tdsType": "rent_194I",
            "amount": 300000,  # Annual rent
            "panAvailable": True,
            "taxableIncome": 0
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-tds", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Rent TDS threshold is 2.4L, so 3L should attract TDS
            if not result['applicable']:
                self.log_test(test_name, False, f"TDS should be applicable for rent ₹3L (threshold ₹2.4L)")
                return
            
            if result['tdsRate'] != 10:
                self.log_test(test_name, False, f"Rent TDS rate should be 10%, got {result['tdsRate']}%")
                return
            
            expected_tds = 30000  # 10% of 3L
            if result['tdsAmount'] != expected_tds:
                self.log_test(test_name, False, f"Rent TDS calculation error")
                return
            
            self.log_test(test_name, True, f"Rent TDS: ₹{result['tdsAmount']:,} at {result['tdsRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_tds_professional_194j(self):
        """Test professional fees TDS (194J) calculation"""
        test_name = "TDS - Professional Fees (194J)"
        
        payload = {
            "tdsType": "professional_194J",
            "amount": 50000,
            "panAvailable": True,
            "taxableIncome": 0
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-tds", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Professional fees threshold is 30K, so 50K should attract TDS
            if not result['applicable']:
                self.log_test(test_name, False, f"TDS should be applicable for professional fees ₹50K (threshold ₹30K)")
                return
            
            if result['tdsRate'] != 10:
                self.log_test(test_name, False, f"Professional fees TDS rate should be 10%, got {result['tdsRate']}%")
                return
            
            self.log_test(test_name, True, f"Professional TDS: ₹{result['tdsAmount']:,} at {result['tdsRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_tds_without_pan(self):
        """Test TDS calculation without PAN"""
        test_name = "TDS - Without PAN (Higher Rate)"
        
        payload = {
            "tdsType": "professional_194J",
            "amount": 50000,
            "panAvailable": False,
            "taxableIncome": 0
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-tds", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Without PAN, TDS rate should be 20%
            if result['tdsRate'] != 20:
                self.log_test(test_name, False, f"TDS rate without PAN should be 20%, got {result['tdsRate']}%")
                return
            
            expected_tds = 10000  # 20% of 50K
            if result['tdsAmount'] != expected_tds:
                self.log_test(test_name, False, f"TDS without PAN calculation error")
                return
            
            self.log_test(test_name, True, f"TDS without PAN: ₹{result['tdsAmount']:,} at {result['tdsRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_calculation_history(self):
        """Test calculation history API"""
        test_name = "Calculation History"
        
        try:
            # Test general history
            response = requests.get(f"{BACKEND_URL}/calculation-history")
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            
            if not data.get('success'):
                self.log_test(test_name, False, f"API returned success=false: {data}")
                return
            
            # Validate response structure
            if 'data' not in data or 'count' not in data:
                self.log_test(test_name, False, "Missing data or count in response")
                return
            
            # Test filtered history
            response_filtered = requests.get(f"{BACKEND_URL}/calculation-history?type=income_tax&limit=5")
            
            if response_filtered.status_code != 200:
                self.log_test(test_name, False, f"Filtered history failed: HTTP {response_filtered.status_code}")
                return
            
            filtered_data = response_filtered.json()
            
            self.log_test(test_name, True, f"History retrieved: {data['count']} records, Filtered: {filtered_data['count']} records")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_error_handling(self):
        """Test API error handling"""
        test_name = "Error Handling - Invalid Input"
        
        # Test with invalid income tax request
        invalid_payload = {
            "income": {
                "salary": "invalid",  # Should be number
                "business": 0,
                "other": 0
            },
            "deductions": {},
            "regime": "new"
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-income-tax", json=invalid_payload)
            
            # Should return error (422 for validation error or 500 for server error)
            if response.status_code == 200:
                self.log_test(test_name, False, "API should reject invalid input but returned 200")
                return
            
            self.log_test(test_name, True, f"Properly handled invalid input with HTTP {response.status_code}")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def run_all_tests(self):
        """Run all backend tests"""
        print("=" * 80)
        print("INDIAN TAX CALCULATOR - BACKEND API TESTS")
        print("=" * 80)
        print(f"Testing Backend URL: {BACKEND_URL}")
        print(f"Test Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 80)
        
        # Run all tests
        self.test_income_tax_new_regime()
        self.test_income_tax_old_regime_with_deductions()
        self.test_regime_comparison()
        self.test_capital_gains_equity_ltcg()
        self.test_capital_gains_equity_stcg()
        self.test_capital_gains_other_assets_with_indexation()
        self.test_tds_salary()
        self.test_tds_rent_194i()
        self.test_tds_professional_194j()
        self.test_tds_without_pan()
        self.test_calculation_history()
        self.test_error_handling()
        
        # Print summary
        print("=" * 80)
        print("TEST SUMMARY")
        print("=" * 80)
        
        total_tests = len(self.test_results)
        passed_tests = total_tests - len(self.failed_tests)
        
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests}")
        print(f"Failed: {len(self.failed_tests)}")
        print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        
        if self.failed_tests:
            print("\nFAILED TESTS:")
            for failure in self.failed_tests:
                print(f"❌ {failure}")
        
        print("=" * 80)
        
        return len(self.failed_tests) == 0

if __name__ == "__main__":
    tester = TaxCalculatorTester()
    success = tester.run_all_tests()
    
    if not success:
        sys.exit(1)
    else:
        print("🎉 All tests passed!")
        sys.exit(0)"

class TaxCalculatorTester:
    def __init__(self):
        self.test_results = []
        self.failed_tests = []
        
    def log_test(self, test_name: str, success: bool, details: str = ""):
        """Log test results"""
        status = "✅ PASS" if success else "❌ FAIL"
        result = f"{status} - {test_name}"
        if details:
            result += f": {details}"
        
        self.test_results.append(result)
        if not success:
            self.failed_tests.append(f"{test_name}: {details}")
        print(result)
    
    def test_income_tax_new_regime(self):
        """Test income tax calculation for new regime"""
        test_name = "Income Tax - New Regime (Salary: 15L, Business: 3L)"
        
        payload = {
            "income": {
                "salary": 1500000,
                "business": 300000,
                "other": 0
            },
            "deductions": {
                "section80C": 0,
                "section80CCD1B": 0,
                "section80D": 0,
                "section80DParents": 0,
                "hra": 0,
                "homeLoan": 0,
                "section80E": 0,
                "section80G": 0
            },
            "regime": "new"
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-income-tax", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            
            if not data.get('success'):
                self.log_test(test_name, False, f"API returned success=false: {data}")
                return
            
            result = data.get('data', {})
            
            # Validate response structure
            required_fields = ['grossIncome', 'taxableIncome', 'baseTax', 'totalTax', 'effectiveRate']
            missing_fields = [field for field in required_fields if field not in result]
            
            if missing_fields:
                self.log_test(test_name, False, f"Missing fields: {missing_fields}")
                return
            
            # Validate calculations for new regime
            expected_gross = 1800000  # 15L + 3L
            expected_taxable = 1725000  # Gross - 75K standard deduction
            
            if result['grossIncome'] != expected_gross:
                self.log_test(test_name, False, f"Gross income mismatch: expected {expected_gross}, got {result['grossIncome']}")
                return
            
            if result['taxableIncome'] != expected_taxable:
                self.log_test(test_name, False, f"Taxable income mismatch: expected {expected_taxable}, got {result['taxableIncome']}")
                return
            
            # Check if tax is calculated (should be > 0 for this income)
            if result['totalTax'] <= 0:
                self.log_test(test_name, False, f"Total tax should be > 0 for income 18L, got {result['totalTax']}")
                return
            
            self.log_test(test_name, True, f"Tax: ₹{result['totalTax']:,}, Rate: {result['effectiveRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_income_tax_old_regime_with_deductions(self):
        """Test income tax calculation for old regime with deductions"""
        test_name = "Income Tax - Old Regime with Deductions"
        
        payload = {
            "income": {
                "salary": 1200000,
                "business": 0,
                "other": 0
            },
            "deductions": {
                "section80C": 150000,
                "section80CCD1B": 50000,
                "section80D": 25000,
                "section80DParents": 0,
                "hra": 200000,
                "homeLoan": 100000,
                "section80E": 0,
                "section80G": 0
            },
            "regime": "old"
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-income-tax", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Validate deductions are applied in old regime
            total_deductions = 150000 + 50000 + 25000 + 200000 + 100000 + 50000  # Including standard deduction
            expected_taxable = 1200000 - total_deductions
            
            if result['taxableIncome'] != max(0, expected_taxable):
                self.log_test(test_name, False, f"Deductions not applied correctly in old regime")
                return
            
            self.log_test(test_name, True, f"Deductions applied: ₹{result['deductions']:,}")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_regime_comparison(self):
        """Test regime comparison API"""
        test_name = "Regime Comparison"
        
        payload = {
            "income": {
                "salary": 1000000,
                "business": 0,
                "other": 0
            },
            "deductions": {
                "section80C": 150000,
                "section80CCD1B": 0,
                "section80D": 25000,
                "section80DParents": 0,
                "hra": 100000,
                "homeLoan": 0,
                "section80E": 0,
                "section80G": 0
            },
            "regime": "new"
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/compare-regimes", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Validate comparison structure
            required_fields = ['new_regime', 'old_regime', 'savings', 'recommended']
            missing_fields = [field for field in required_fields if field not in result]
            
            if missing_fields:
                self.log_test(test_name, False, f"Missing fields: {missing_fields}")
                return
            
            # Check if both regime calculations exist
            if 'totalTax' not in result['new_regime'] or 'totalTax' not in result['old_regime']:
                self.log_test(test_name, False, "Missing tax calculations in regime comparison")
                return
            
            new_tax = result['new_regime']['totalTax']
            old_tax = result['old_regime']['totalTax']
            savings = result['savings']
            
            self.log_test(test_name, True, f"New: ₹{new_tax:,}, Old: ₹{old_tax:,}, Savings: ₹{savings:,}, Recommended: {result['recommended']}")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_capital_gains_equity_ltcg(self):
        """Test equity LTCG calculation"""
        test_name = "Capital Gains - Equity LTCG"
        
        payload = {
            "assetType": "equity",
            "holdingPeriod": "long",
            "purchasePrice": 500000,
            "salePrice": 1200000,
            "indexation": False
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-capital-gains", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Validate response structure
            required_fields = ['gains', 'exemptionAmount', 'taxableGain', 'taxRate', 'totalTax']
            missing_fields = [field for field in required_fields if field not in result]
            
            if missing_fields:
                self.log_test(test_name, False, f"Missing fields: {missing_fields}")
                return
            
            # Validate calculations
            expected_gains = 700000  # 12L - 5L
            expected_exemption = 125000  # LTCG equity exemption
            expected_taxable = 575000  # 7L - 1.25L
            expected_rate = 12.5  # LTCG equity rate
            
            if result['gains'] != expected_gains:
                self.log_test(test_name, False, f"Gains calculation error: expected {expected_gains}, got {result['gains']}")
                return
            
            if result['exemptionAmount'] != expected_exemption:
                self.log_test(test_name, False, f"Exemption error: expected {expected_exemption}, got {result['exemptionAmount']}")
                return
            
            if result['taxRate'] != expected_rate:
                self.log_test(test_name, False, f"Tax rate error: expected {expected_rate}%, got {result['taxRate']}%")
                return
            
            self.log_test(test_name, True, f"Gains: ₹{result['gains']:,}, Tax: ₹{result['totalTax']:,} at {result['taxRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_capital_gains_equity_stcg(self):
        """Test equity STCG calculation"""
        test_name = "Capital Gains - Equity STCG"
        
        payload = {
            "assetType": "equity",
            "holdingPeriod": "short",
            "purchasePrice": 300000,
            "salePrice": 400000,
            "indexation": False
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-capital-gains", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Validate STCG equity calculations
            expected_gains = 100000
            expected_rate = 20  # STCG equity rate
            
            if result['gains'] != expected_gains:
                self.log_test(test_name, False, f"Gains calculation error")
                return
            
            if result['taxRate'] != expected_rate:
                self.log_test(test_name, False, f"STCG rate should be 20%, got {result['taxRate']}%")
                return
            
            # No exemption for STCG
            if result['exemptionAmount'] != 0:
                self.log_test(test_name, False, f"STCG should have no exemption, got {result['exemptionAmount']}")
                return
            
            self.log_test(test_name, True, f"STCG Tax: ₹{result['totalTax']:,} at {result['taxRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_capital_gains_other_assets_with_indexation(self):
        """Test other assets LTCG with indexation"""
        test_name = "Capital Gains - Other Assets with Indexation"
        
        payload = {
            "assetType": "property",
            "holdingPeriod": "long",
            "purchasePrice": 2000000,
            "salePrice": 3500000,
            "indexation": True
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-capital-gains", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Validate other assets LTCG with indexation
            expected_rate = 20  # LTCG other assets with indexation
            
            if result['taxRate'] != expected_rate:
                self.log_test(test_name, False, f"LTCG with indexation rate should be 20%, got {result['taxRate']}%")
                return
            
            self.log_test(test_name, True, f"LTCG with indexation: ₹{result['totalTax']:,} at {result['taxRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_tds_salary(self):
        """Test salary TDS calculation"""
        test_name = "TDS - Salary"
        
        payload = {
            "tdsType": "salary",
            "amount": 100000,  # Monthly salary
            "panAvailable": True,
            "taxableIncome": 1200000  # Annual income
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-tds", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Validate TDS structure
            required_fields = ['amount', 'tdsRate', 'tdsAmount', 'netAmount', 'applicable']
            missing_fields = [field for field in required_fields if field not in result]
            
            if missing_fields:
                self.log_test(test_name, False, f"Missing fields: {missing_fields}")
                return
            
            # For 12L annual income, TDS rate should be 15% (new regime slab)
            if result['tdsRate'] != 15:
                self.log_test(test_name, False, f"TDS rate for 12L income should be 15%, got {result['tdsRate']}%")
                return
            
            expected_tds = 15000  # 15% of 1L
            if result['tdsAmount'] != expected_tds:
                self.log_test(test_name, False, f"TDS amount calculation error: expected {expected_tds}, got {result['tdsAmount']}")
                return
            
            self.log_test(test_name, True, f"Salary TDS: ₹{result['tdsAmount']:,} at {result['tdsRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_tds_rent_194i(self):
        """Test rent TDS (194I) calculation"""
        test_name = "TDS - Rent (194I)"
        
        payload = {
            "tdsType": "rent_194I",
            "amount": 300000,  # Annual rent
            "panAvailable": True,
            "taxableIncome": 0
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-tds", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Rent TDS threshold is 2.4L, so 3L should attract TDS
            if not result['applicable']:
                self.log_test(test_name, False, f"TDS should be applicable for rent ₹3L (threshold ₹2.4L)")
                return
            
            if result['tdsRate'] != 10:
                self.log_test(test_name, False, f"Rent TDS rate should be 10%, got {result['tdsRate']}%")
                return
            
            expected_tds = 30000  # 10% of 3L
            if result['tdsAmount'] != expected_tds:
                self.log_test(test_name, False, f"Rent TDS calculation error")
                return
            
            self.log_test(test_name, True, f"Rent TDS: ₹{result['tdsAmount']:,} at {result['tdsRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_tds_professional_194j(self):
        """Test professional fees TDS (194J) calculation"""
        test_name = "TDS - Professional Fees (194J)"
        
        payload = {
            "tdsType": "professional_194J",
            "amount": 50000,
            "panAvailable": True,
            "taxableIncome": 0
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-tds", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Professional fees threshold is 30K, so 50K should attract TDS
            if not result['applicable']:
                self.log_test(test_name, False, f"TDS should be applicable for professional fees ₹50K (threshold ₹30K)")
                return
            
            if result['tdsRate'] != 10:
                self.log_test(test_name, False, f"Professional fees TDS rate should be 10%, got {result['tdsRate']}%")
                return
            
            self.log_test(test_name, True, f"Professional TDS: ₹{result['tdsAmount']:,} at {result['tdsRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_tds_without_pan(self):
        """Test TDS calculation without PAN"""
        test_name = "TDS - Without PAN (Higher Rate)"
        
        payload = {
            "tdsType": "professional_194J",
            "amount": 50000,
            "panAvailable": False,
            "taxableIncome": 0
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-tds", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Without PAN, TDS rate should be 20%
            if result['tdsRate'] != 20:
                self.log_test(test_name, False, f"TDS rate without PAN should be 20%, got {result['tdsRate']}%")
                return
            
            expected_tds = 10000  # 20% of 50K
            if result['tdsAmount'] != expected_tds:
                self.log_test(test_name, False, f"TDS without PAN calculation error")
                return
            
            self.log_test(test_name, True, f"TDS without PAN: ₹{result['tdsAmount']:,} at {result['tdsRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_calculation_history(self):
        """Test calculation history API"""
        test_name = "Calculation History"
        
        try:
            # Test general history
            response = requests.get(f"{BACKEND_URL}/calculation-history")
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            
            if not data.get('success'):
                self.log_test(test_name, False, f"API returned success=false: {data}")
                return
            
            # Validate response structure
            if 'data' not in data or 'count' not in data:
                self.log_test(test_name, False, "Missing data or count in response")
                return
            
            # Test filtered history
            response_filtered = requests.get(f"{BACKEND_URL}/calculation-history?type=income_tax&limit=5")
            
            if response_filtered.status_code != 200:
                self.log_test(test_name, False, f"Filtered history failed: HTTP {response_filtered.status_code}")
                return
            
            filtered_data = response_filtered.json()
            
            self.log_test(test_name, True, f"History retrieved: {data['count']} records, Filtered: {filtered_data['count']} records")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_error_handling(self):
        """Test API error handling"""
        test_name = "Error Handling - Invalid Input"
        
        # Test with invalid income tax request
        invalid_payload = {
            "income": {
                "salary": "invalid",  # Should be number
                "business": 0,
                "other": 0
            },
            "deductions": {},
            "regime": "new"
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-income-tax", json=invalid_payload)
            
            # Should return error (422 for validation error or 500 for server error)
            if response.status_code == 200:
                self.log_test(test_name, False, "API should reject invalid input but returned 200")
                return
            
            self.log_test(test_name, True, f"Properly handled invalid input with HTTP {response.status_code}")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def run_all_tests(self):
        """Run all backend tests"""
        print("=" * 80)
        print("INDIAN TAX CALCULATOR - BACKEND API TESTS")
        print("=" * 80)
        print(f"Testing Backend URL: {BACKEND_URL}")
        print(f"Test Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 80)
        
        # Run all tests
        self.test_income_tax_new_regime()
        self.test_income_tax_old_regime_with_deductions()
        self.test_regime_comparison()
        self.test_capital_gains_equity_ltcg()
        self.test_capital_gains_equity_stcg()
        self.test_capital_gains_other_assets_with_indexation()
        self.test_tds_salary()
        self.test_tds_rent_194i()
        self.test_tds_professional_194j()
        self.test_tds_without_pan()
        self.test_calculation_history()
        self.test_error_handling()
        
        # Print summary
        print("=" * 80)
        print("TEST SUMMARY")
        print("=" * 80)
        
        total_tests = len(self.test_results)
        passed_tests = total_tests - len(self.failed_tests)
        
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests}")
        print(f"Failed: {len(self.failed_tests)}")
        print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        
        if self.failed_tests:
            print("\nFAILED TESTS:")
            for failure in self.failed_tests:
                print(f"❌ {failure}")
        
        print("=" * 80)
        
        return len(self.failed_tests) == 0

if __name__ == "__main__":
    tester = TaxCalculatorTester()
    success = tester.run_all_tests()
    
    if not success:
        sys.exit(1)
    else:
        print("🎉 All tests passed!")
        sys.exit(0)"

class TaxCalculatorTester:
    def __init__(self):
        self.test_results = []
        self.failed_tests = []
        
    def log_test(self, test_name: str, success: bool, details: str = ""):
        """Log test results"""
        status = "✅ PASS" if success else "❌ FAIL"
        result = f"{status} - {test_name}"
        if details:
            result += f": {details}"
        
        self.test_results.append(result)
        if not success:
            self.failed_tests.append(f"{test_name}: {details}")
        print(result)
    
    def test_income_tax_new_regime(self):
        """Test income tax calculation for new regime"""
        test_name = "Income Tax - New Regime (Salary: 15L, Business: 3L)"
        
        payload = {
            "income": {
                "salary": 1500000,
                "business": 300000,
                "other": 0
            },
            "deductions": {
                "section80C": 0,
                "section80CCD1B": 0,
                "section80D": 0,
                "section80DParents": 0,
                "hra": 0,
                "homeLoan": 0,
                "section80E": 0,
                "section80G": 0
            },
            "regime": "new"
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-income-tax", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            
            if not data.get('success'):
                self.log_test(test_name, False, f"API returned success=false: {data}")
                return
            
            result = data.get('data', {})
            
            # Validate response structure
            required_fields = ['grossIncome', 'taxableIncome', 'baseTax', 'totalTax', 'effectiveRate']
            missing_fields = [field for field in required_fields if field not in result]
            
            if missing_fields:
                self.log_test(test_name, False, f"Missing fields: {missing_fields}")
                return
            
            # Validate calculations for new regime
            expected_gross = 1800000  # 15L + 3L
            expected_taxable = 1725000  # Gross - 75K standard deduction
            
            if result['grossIncome'] != expected_gross:
                self.log_test(test_name, False, f"Gross income mismatch: expected {expected_gross}, got {result['grossIncome']}")
                return
            
            if result['taxableIncome'] != expected_taxable:
                self.log_test(test_name, False, f"Taxable income mismatch: expected {expected_taxable}, got {result['taxableIncome']}")
                return
            
            # Check if tax is calculated (should be > 0 for this income)
            if result['totalTax'] <= 0:
                self.log_test(test_name, False, f"Total tax should be > 0 for income 18L, got {result['totalTax']}")
                return
            
            self.log_test(test_name, True, f"Tax: ₹{result['totalTax']:,}, Rate: {result['effectiveRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_income_tax_old_regime_with_deductions(self):
        """Test income tax calculation for old regime with deductions"""
        test_name = "Income Tax - Old Regime with Deductions"
        
        payload = {
            "income": {
                "salary": 1200000,
                "business": 0,
                "other": 0
            },
            "deductions": {
                "section80C": 150000,
                "section80CCD1B": 50000,
                "section80D": 25000,
                "section80DParents": 0,
                "hra": 200000,
                "homeLoan": 100000,
                "section80E": 0,
                "section80G": 0
            },
            "regime": "old"
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-income-tax", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Validate deductions are applied in old regime
            total_deductions = 150000 + 50000 + 25000 + 200000 + 100000 + 50000  # Including standard deduction
            expected_taxable = 1200000 - total_deductions
            
            if result['taxableIncome'] != max(0, expected_taxable):
                self.log_test(test_name, False, f"Deductions not applied correctly in old regime")
                return
            
            self.log_test(test_name, True, f"Deductions applied: ₹{result['deductions']:,}")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_regime_comparison(self):
        """Test regime comparison API"""
        test_name = "Regime Comparison"
        
        payload = {
            "income": {
                "salary": 1000000,
                "business": 0,
                "other": 0
            },
            "deductions": {
                "section80C": 150000,
                "section80CCD1B": 0,
                "section80D": 25000,
                "section80DParents": 0,
                "hra": 100000,
                "homeLoan": 0,
                "section80E": 0,
                "section80G": 0
            },
            "regime": "new"
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/compare-regimes", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Validate comparison structure
            required_fields = ['new_regime', 'old_regime', 'savings', 'recommended']
            missing_fields = [field for field in required_fields if field not in result]
            
            if missing_fields:
                self.log_test(test_name, False, f"Missing fields: {missing_fields}")
                return
            
            # Check if both regime calculations exist
            if 'totalTax' not in result['new_regime'] or 'totalTax' not in result['old_regime']:
                self.log_test(test_name, False, "Missing tax calculations in regime comparison")
                return
            
            new_tax = result['new_regime']['totalTax']
            old_tax = result['old_regime']['totalTax']
            savings = result['savings']
            
            self.log_test(test_name, True, f"New: ₹{new_tax:,}, Old: ₹{old_tax:,}, Savings: ₹{savings:,}, Recommended: {result['recommended']}")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_capital_gains_equity_ltcg(self):
        """Test equity LTCG calculation"""
        test_name = "Capital Gains - Equity LTCG"
        
        payload = {
            "assetType": "equity",
            "holdingPeriod": "long",
            "purchasePrice": 500000,
            "salePrice": 1200000,
            "indexation": False
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-capital-gains", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Validate response structure
            required_fields = ['gains', 'exemptionAmount', 'taxableGain', 'taxRate', 'totalTax']
            missing_fields = [field for field in required_fields if field not in result]
            
            if missing_fields:
                self.log_test(test_name, False, f"Missing fields: {missing_fields}")
                return
            
            # Validate calculations
            expected_gains = 700000  # 12L - 5L
            expected_exemption = 125000  # LTCG equity exemption
            expected_taxable = 575000  # 7L - 1.25L
            expected_rate = 12.5  # LTCG equity rate
            
            if result['gains'] != expected_gains:
                self.log_test(test_name, False, f"Gains calculation error: expected {expected_gains}, got {result['gains']}")
                return
            
            if result['exemptionAmount'] != expected_exemption:
                self.log_test(test_name, False, f"Exemption error: expected {expected_exemption}, got {result['exemptionAmount']}")
                return
            
            if result['taxRate'] != expected_rate:
                self.log_test(test_name, False, f"Tax rate error: expected {expected_rate}%, got {result['taxRate']}%")
                return
            
            self.log_test(test_name, True, f"Gains: ₹{result['gains']:,}, Tax: ₹{result['totalTax']:,} at {result['taxRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_capital_gains_equity_stcg(self):
        """Test equity STCG calculation"""
        test_name = "Capital Gains - Equity STCG"
        
        payload = {
            "assetType": "equity",
            "holdingPeriod": "short",
            "purchasePrice": 300000,
            "salePrice": 400000,
            "indexation": False
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-capital-gains", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Validate STCG equity calculations
            expected_gains = 100000
            expected_rate = 20  # STCG equity rate
            
            if result['gains'] != expected_gains:
                self.log_test(test_name, False, f"Gains calculation error")
                return
            
            if result['taxRate'] != expected_rate:
                self.log_test(test_name, False, f"STCG rate should be 20%, got {result['taxRate']}%")
                return
            
            # No exemption for STCG
            if result['exemptionAmount'] != 0:
                self.log_test(test_name, False, f"STCG should have no exemption, got {result['exemptionAmount']}")
                return
            
            self.log_test(test_name, True, f"STCG Tax: ₹{result['totalTax']:,} at {result['taxRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_capital_gains_other_assets_with_indexation(self):
        """Test other assets LTCG with indexation"""
        test_name = "Capital Gains - Other Assets with Indexation"
        
        payload = {
            "assetType": "property",
            "holdingPeriod": "long",
            "purchasePrice": 2000000,
            "salePrice": 3500000,
            "indexation": True
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-capital-gains", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Validate other assets LTCG with indexation
            expected_rate = 20  # LTCG other assets with indexation
            
            if result['taxRate'] != expected_rate:
                self.log_test(test_name, False, f"LTCG with indexation rate should be 20%, got {result['taxRate']}%")
                return
            
            self.log_test(test_name, True, f"LTCG with indexation: ₹{result['totalTax']:,} at {result['taxRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_tds_salary(self):
        """Test salary TDS calculation"""
        test_name = "TDS - Salary"
        
        payload = {
            "tdsType": "salary",
            "amount": 100000,  # Monthly salary
            "panAvailable": True,
            "taxableIncome": 1200000  # Annual income
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-tds", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Validate TDS structure
            required_fields = ['amount', 'tdsRate', 'tdsAmount', 'netAmount', 'applicable']
            missing_fields = [field for field in required_fields if field not in result]
            
            if missing_fields:
                self.log_test(test_name, False, f"Missing fields: {missing_fields}")
                return
            
            # For 12L annual income, TDS rate should be 15% (new regime slab)
            if result['tdsRate'] != 15:
                self.log_test(test_name, False, f"TDS rate for 12L income should be 15%, got {result['tdsRate']}%")
                return
            
            expected_tds = 15000  # 15% of 1L
            if result['tdsAmount'] != expected_tds:
                self.log_test(test_name, False, f"TDS amount calculation error: expected {expected_tds}, got {result['tdsAmount']}")
                return
            
            self.log_test(test_name, True, f"Salary TDS: ₹{result['tdsAmount']:,} at {result['tdsRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_tds_rent_194i(self):
        """Test rent TDS (194I) calculation"""
        test_name = "TDS - Rent (194I)"
        
        payload = {
            "tdsType": "rent_194I",
            "amount": 300000,  # Annual rent
            "panAvailable": True,
            "taxableIncome": 0
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-tds", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Rent TDS threshold is 2.4L, so 3L should attract TDS
            if not result['applicable']:
                self.log_test(test_name, False, f"TDS should be applicable for rent ₹3L (threshold ₹2.4L)")
                return
            
            if result['tdsRate'] != 10:
                self.log_test(test_name, False, f"Rent TDS rate should be 10%, got {result['tdsRate']}%")
                return
            
            expected_tds = 30000  # 10% of 3L
            if result['tdsAmount'] != expected_tds:
                self.log_test(test_name, False, f"Rent TDS calculation error")
                return
            
            self.log_test(test_name, True, f"Rent TDS: ₹{result['tdsAmount']:,} at {result['tdsRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_tds_professional_194j(self):
        """Test professional fees TDS (194J) calculation"""
        test_name = "TDS - Professional Fees (194J)"
        
        payload = {
            "tdsType": "professional_194J",
            "amount": 50000,
            "panAvailable": True,
            "taxableIncome": 0
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-tds", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Professional fees threshold is 30K, so 50K should attract TDS
            if not result['applicable']:
                self.log_test(test_name, False, f"TDS should be applicable for professional fees ₹50K (threshold ₹30K)")
                return
            
            if result['tdsRate'] != 10:
                self.log_test(test_name, False, f"Professional fees TDS rate should be 10%, got {result['tdsRate']}%")
                return
            
            self.log_test(test_name, True, f"Professional TDS: ₹{result['tdsAmount']:,} at {result['tdsRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_tds_without_pan(self):
        """Test TDS calculation without PAN"""
        test_name = "TDS - Without PAN (Higher Rate)"
        
        payload = {
            "tdsType": "professional_194J",
            "amount": 50000,
            "panAvailable": False,
            "taxableIncome": 0
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-tds", json=payload)
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            result = data.get('data', {})
            
            # Without PAN, TDS rate should be 20%
            if result['tdsRate'] != 20:
                self.log_test(test_name, False, f"TDS rate without PAN should be 20%, got {result['tdsRate']}%")
                return
            
            expected_tds = 10000  # 20% of 50K
            if result['tdsAmount'] != expected_tds:
                self.log_test(test_name, False, f"TDS without PAN calculation error")
                return
            
            self.log_test(test_name, True, f"TDS without PAN: ₹{result['tdsAmount']:,} at {result['tdsRate']}%")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_calculation_history(self):
        """Test calculation history API"""
        test_name = "Calculation History"
        
        try:
            # Test general history
            response = requests.get(f"{BACKEND_URL}/calculation-history")
            
            if response.status_code != 200:
                self.log_test(test_name, False, f"HTTP {response.status_code}: {response.text}")
                return
            
            data = response.json()
            
            if not data.get('success'):
                self.log_test(test_name, False, f"API returned success=false: {data}")
                return
            
            # Validate response structure
            if 'data' not in data or 'count' not in data:
                self.log_test(test_name, False, "Missing data or count in response")
                return
            
            # Test filtered history
            response_filtered = requests.get(f"{BACKEND_URL}/calculation-history?type=income_tax&limit=5")
            
            if response_filtered.status_code != 200:
                self.log_test(test_name, False, f"Filtered history failed: HTTP {response_filtered.status_code}")
                return
            
            filtered_data = response_filtered.json()
            
            self.log_test(test_name, True, f"History retrieved: {data['count']} records, Filtered: {filtered_data['count']} records")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def test_error_handling(self):
        """Test API error handling"""
        test_name = "Error Handling - Invalid Input"
        
        # Test with invalid income tax request
        invalid_payload = {
            "income": {
                "salary": "invalid",  # Should be number
                "business": 0,
                "other": 0
            },
            "deductions": {},
            "regime": "new"
        }
        
        try:
            response = requests.post(f"{BACKEND_URL}/calculate-income-tax", json=invalid_payload)
            
            # Should return error (422 for validation error or 500 for server error)
            if response.status_code == 200:
                self.log_test(test_name, False, "API should reject invalid input but returned 200")
                return
            
            self.log_test(test_name, True, f"Properly handled invalid input with HTTP {response.status_code}")
            
        except Exception as e:
            self.log_test(test_name, False, f"Exception: {str(e)}")
    
    def run_all_tests(self):
        """Run all backend tests"""
        print("=" * 80)
        print("INDIAN TAX CALCULATOR - BACKEND API TESTS")
        print("=" * 80)
        print(f"Testing Backend URL: {BACKEND_URL}")
        print(f"Test Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 80)
        
        # Run all tests
        self.test_income_tax_new_regime()
        self.test_income_tax_old_regime_with_deductions()
        self.test_regime_comparison()
        self.test_capital_gains_equity_ltcg()
        self.test_capital_gains_equity_stcg()
        self.test_capital_gains_other_assets_with_indexation()
        self.test_tds_salary()
        self.test_tds_rent_194i()
        self.test_tds_professional_194j()
        self.test_tds_without_pan()
        self.test_calculation_history()
        self.test_error_handling()
        
        # Print summary
        print("=" * 80)
        print("TEST SUMMARY")
        print("=" * 80)
        
        total_tests = len(self.test_results)
        passed_tests = total_tests - len(self.failed_tests)
        
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests}")
        print(f"Failed: {len(self.failed_tests)}")
        print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        
        if self.failed_tests:
            print("\nFAILED TESTS:")
            for failure in self.failed_tests:
                print(f"❌ {failure}")
        
        print("=" * 80)
        
        return len(self.failed_tests) == 0

if __name__ == "__main__":
    tester = TaxCalculatorTester()
    success = tester.run_all_tests()
    
    if not success:
        sys.exit(1)
    else:
        print("🎉 All tests passed!")
        sys.exit(0)