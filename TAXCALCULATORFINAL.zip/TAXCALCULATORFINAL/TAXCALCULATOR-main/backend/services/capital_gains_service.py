from typing import Dict, Any

class CapitalGainsService:
    # Capital gains tax rates (Budget 2025)
    RATES = {
        'STCG_equity': 20,  # Listed equity/mutual funds (STT applicable)
        'LTCG_equity': 12.5,  # Listed equity/mutual funds
        'LTCG_equity_exemption': 125000,  # Exemption limit
        'LTCG_other': 12.5,  # Other assets (property, gold, debt funds) - no indexation from July 23, 2024
        'STCG_other_max': 30  # Added to income, taxed at slab rate
    }
    
    CESS_RATE = 4

    @classmethod
    def calculate_capital_gains_tax(cls, asset_type: str, holding_period: str, 
                                   purchase_price: float, sale_price: float, 
                                   indexation: bool = False) -> Dict[str, Any]:
        
        gains = sale_price - purchase_price
        
        if gains <= 0:
            return {
                'gains': round(gains),
                'exemptionAmount': 0,
                'taxableGain': 0,
                'taxRate': 0,
                'baseTax': 0,
                'cess': 0,
                'totalTax': 0,
                'netProceeds': round(sale_price),
                'message': 'No capital gains to tax'
            }
        
        exemption_amount = 0
        taxable_gain = gains
        tax_rate = 0
        description = ""
        
        if asset_type == 'equity':
            if holding_period == 'short':
                # STCG on equity @ 20% (Budget 2025)
                tax_rate = cls.RATES['STCG_equity']
                description = 'Short-term capital gains on equity taxed at 20%'
            else:
                # LTCG on equity @ 12.5% above exemption (Budget 2025)
                exemption_amount = cls.RATES['LTCG_equity_exemption']
                taxable_gain = max(0, gains - exemption_amount)
                tax_rate = cls.RATES['LTCG_equity']
                description = f'Long-term capital gains on equity taxed at 12.5% (₹{exemption_amount:,.0f} exemption applied)'
        else:
            if holding_period == 'short':
                # STCG on other assets - added to income
                tax_rate = cls.RATES['STCG_other_max']
                description = 'Short-term capital gains added to income (shown at max slab 30%)'
            else:
                # LTCG on other assets @ 12.5% (no indexation from July 23, 2024 - Budget 2025)
                tax_rate = cls.RATES['LTCG_other']
                description = 'Long-term capital gains taxed at 12.5% (indexation removed for assets purchased after July 23, 2024)'
        
        # Calculate tax
        base_tax = (taxable_gain * tax_rate) / 100
        cess = (base_tax * cls.CESS_RATE) / 100
        total_tax = base_tax + cess
        
        return {
            'gains': round(gains),
            'exemptionAmount': round(exemption_amount),
            'taxableGain': round(taxable_gain),
            'taxRate': tax_rate,
            'baseTax': round(base_tax),
            'cess': round(cess),
            'totalTax': round(total_tax),
            'netProceeds': round(sale_price - total_tax),
            'description': description
        }
