from typing import Dict, Any

class TDSService:
    # TDS rates (Budget 2025)
    RATES = {
        'rent_194I': 10,
        'professional_194J': 10,
        'contract_194C_individual': 1,
        'contract_194C_company': 2,
        'commission_194H': 5,
        'interest_194A': 10,
        'dividend_194': 10,
        'lottery_194B': 30
    }
    
    # Threshold limits (Budget 2025)
    THRESHOLDS = {
        'rent_194I': 600000,  # Annual (₹50,000 per month)
        'professional_194J': 30000,  # Per transaction
        'contract_194C': 30000,  # Per transaction (aggregate ₹1,00,000)
        'commission_194H': 15000,
        'interest_194A': 40000,
        'dividend_194': 5000,
        'lottery_194B': 10000
    }
    
    # Higher rate when PAN not available
    NO_PAN_RATE = 20

    @classmethod
    def calculate_tds(cls, tds_type: str, amount: float, pan_available: bool = True, 
                     taxable_income: float = 0) -> Dict[str, Any]:
        
        tds_rate = 0
        tds_amount = 0
        threshold = 0
        description = ""
        applicable = False
        
        if tds_type == 'salary':
            # For salary, calculate based on income slab (Budget 2025 new regime)
            if taxable_income <= 1200000:
                tds_rate = 0
                description = 'No TDS if annual income is below ₹12,00,000 (new regime with 87A rebate)'
            elif taxable_income <= 1600000:
                tds_rate = 5
                description = 'TDS at slab rates based on estimated annual income'
            elif taxable_income <= 2000000:
                tds_rate = 10
                description = 'TDS at slab rates based on estimated annual income'
            elif taxable_income <= 2400000:
                tds_rate = 15
                description = 'TDS at slab rates based on estimated annual income'
            else:
                tds_rate = 20
                description = 'TDS at slab rates based on estimated annual income'
            
            tds_amount = (amount * tds_rate) / 100
            applicable = True
            
        elif tds_type == 'lottery_194B':
            threshold = cls.THRESHOLDS['lottery_194B']
            tds_rate = cls.RATES['lottery_194B']
            description = f'TDS on lottery/game show winnings exceeding ₹{threshold:,}'
            applicable = amount > threshold
            tds_amount = (amount * tds_rate) / 100 if applicable else 0
            
        else:
            # Other TDS types
            threshold = cls.THRESHOLDS.get(tds_type, 0)
            
            # Determine rate based on PAN availability
            if pan_available:
                tds_rate = cls.RATES.get(tds_type, 0)
            else:
                tds_rate = cls.NO_PAN_RATE
            
            # Check if threshold is exceeded
            applicable = amount > threshold
            tds_amount = (amount * tds_rate) / 100 if applicable else 0
            
            # Generate description
            descriptions = {
                'rent_194I': f'TDS on rent payments exceeding ₹{threshold:,} per year (₹50,000 per month)',
                'professional_194J': f'TDS on professional/technical fees exceeding ₹{threshold:,}',
                'contract_194C': f'TDS on contractor payments exceeding ₹{threshold:,} per transaction or ₹1,00,000 aggregate',
                'commission_194H': f'TDS on commission or brokerage exceeding ₹{threshold:,}',
                'interest_194A': f'TDS on interest from bank/post office exceeding ₹{threshold:,}',
                'dividend_194': f'TDS on dividend income exceeding ₹{threshold:,}'
            }
            description = descriptions.get(tds_type, 'TDS calculation')
        
        return {
            'amount': round(amount),
            'tdsRate': tds_rate,
            'tdsAmount': round(tds_amount),
            'netAmount': round(amount - tds_amount),
            'threshold': threshold,
            'description': description,
            'applicable': applicable,
            'panStatus': 'Available' if pan_available else 'Not Available'
        }
