from typing import Dict, Any, List
import json
import logging

logger = logging.getLogger(__name__)

class DocumentAnalysisService:
    def __init__(self):
        # Local mode: no external AI dependency or API key required
        pass

    async def analyze_financial_documents(self, file_paths: List[str], mime_types: List[str]) -> Dict[str, Any]:
        """
        Local stub that returns a structured template for extracted data.
        This enables the app to run without external AI services.
        """
        try:
            # Basic heuristic: if any filename hints at Form 16, assume some salary and TDS
            has_form16 = any("form16" in p.lower() for p in file_paths)

            extracted_data: Dict[str, Any] = {
                "income": {
                    "salary": 750000 if has_form16 else 0,
                    "business": 0,
                    "other": 0,
                    "details": [
                        "Assumed income based on local analysis stub" if has_form16 else "No income inferred"
                    ],
                },
                "deductions": {
                    "section80C": 100000 if has_form16 else 0,
                    "section80CCD1B": 0,
                    "section80D": 0,
                    "section80DParents": 0,
                    "hra": 0,
                    "homeLoan": 0,
                    "section80E": 0,
                    "section80G": 0,
                    "details": ["Local stub deductions"],
                },
                "investments": [],
                "tds_paid": {
                    "salary_tds": 50000 if has_form16 else 0,
                    "other_tds": 0,
                    "total": 50000 if has_form16 else 0,
                    "details": ["Local stub TDS"],
                },
                "capital_gains": [],
                "transactions": [],
                "summary": "Local analysis stub executed successfully.",
                "recommendations": [
                    "Provide actual documents for precise extraction or integrate a real model."
                ],
            }

            return {
                "success": True,
                "data": extracted_data,
                "raw_response": json.dumps(extracted_data),
            }
        except Exception as e:
            logger.error(f"Document analysis error (local): {str(e)}")
            return {"success": False, "error": str(e)}

    async def categorize_transactions(self, transactions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Local categorization stub using simple rules based on description keywords.
        """
        try:
            categorized = []
            total_income = 0
            total_deductions = 0
            total_investments = 0

            for t in transactions:
                description = (t.get("description") or "").lower()
                amount = float(t.get("amount") or 0)

                if any(k in description for k in ["salary", "credit", "payout"]):
                    tax_category = "income"
                    tax_section = None
                    total_income += amount
                elif any(k in description for k in ["pf", "ppf", "elss", "lic", "80c"]):
                    tax_category = "deduction"
                    tax_section = "80C"
                    total_deductions += amount
                elif any(k in description for k in ["nps", "80ccd(1b)"]):
                    tax_category = "deduction"
                    tax_section = "80CCD(1B)"
                    total_deductions += amount
                elif any(k in description for k in ["medical", "health", "insurance", "80d"]):
                    tax_category = "deduction"
                    tax_section = "80D"
                    total_deductions += amount
                elif any(k in description for k in ["sip", "mutual fund", "investment"]):
                    tax_category = "investment"
                    tax_section = None
                    total_investments += amount
                else:
                    tax_category = "expense"
                    tax_section = None

                categorized.append(
                    {
                        "original_transaction": t,
                        "tax_category": tax_category,
                        "tax_section": tax_section,
                        "amount_eligible": amount if tax_category in {"deduction", "investment"} else 0,
                        "explanation": "Local rule-based categorization",
                    }
                )

            result = {
                "categorized_transactions": categorized,
                "summary": {
                    "total_income": total_income,
                    "total_deductions": total_deductions,
                    "total_investments": total_investments,
                },
            }

            return {"success": True, "data": result}
        except Exception as e:
            logger.error(f"Transaction categorization error (local): {str(e)}")
            return {"success": False, "error": str(e)}
