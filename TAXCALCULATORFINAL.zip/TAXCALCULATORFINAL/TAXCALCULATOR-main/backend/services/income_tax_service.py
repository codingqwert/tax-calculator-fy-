from typing import Dict, Any, List

class IncomeTaxService:
    # Tax slabs for 2025-26 (Budget 2025)
    TAX_SLABS = {
        'new_regime': [
            {'min': 0, 'max': 400000, 'rate': 0},
            {'min': 400000, 'max': 800000, 'rate': 5},
            {'min': 800000, 'max': 1200000, 'rate': 10},
            {'min': 1200000, 'max': 1600000, 'rate': 15},
            {'min': 1600000, 'max': 2000000, 'rate': 20},
            {'min': 2000000, 'max': 2400000, 'rate': 25},
            {'min': 2400000, 'max': float('inf'), 'rate': 30}
        ],
        'old_regime': [
            {'min': 0, 'max': 250000, 'rate': 0},
            {'min': 250000, 'max': 500000, 'rate': 5},
            {'min': 500000, 'max': 1000000, 'rate': 20},
            {'min': 1000000, 'max': float('inf'), 'rate': 30}
        ]
    }

    SURCHARGE_SLABS = [
        {'min': 5000000, 'max': 10000000, 'rate': 10},
        {'min': 10000000, 'max': 20000000, 'rate': 15},
        {'min': 20000000, 'max': 50000000, 'rate': 25},
        {'min': 50000000, 'max': float('inf'), 'rate': 37}
    ]

    CESS_RATE = 4
    STANDARD_DEDUCTION = {'new_regime': 75000, 'old_regime': 50000}
    REBATE_87A = {
        'new_regime': {'income_limit': 1200000, 'rebate': 60000},
        'old_regime': {'income_limit': 500000, 'rebate': 12500}
    }

    @classmethod
    def calculate_tax(cls, gross_income: float, total_deductions: float, regime: str) -> Dict[str, Any]:
        # Get standard deduction
        standard_ded = cls.STANDARD_DEDUCTION.get(regime, 75000)
        
        # Calculate taxable income
        taxable_income = gross_income - standard_ded
        
        # Apply deductions only for old regime
        if regime == 'old_regime':
            taxable_income -= total_deductions
        
        taxable_income = max(0, taxable_income)
        
        # Calculate base tax
        slabs = cls.TAX_SLABS[regime]
        base_tax = 0
        breakdown = []
        
        for slab in slabs:
            if taxable_income > slab['min']:
                taxable_in_slab = min(taxable_income, slab['max']) - slab['min']
                tax_in_slab = (taxable_in_slab * slab['rate']) / 100
                base_tax += tax_in_slab
                
                if slab['rate'] > 0 or taxable_in_slab > 0:
                    slab_max_display = f"{int(slab['max']/100000)}L" if slab['max'] != float('inf') else "above"
                    slab_min_display = f"{int(slab['min']/100000)}L"
                    breakdown.append({
                        'range': f"{slab_min_display}-{slab_max_display}" if slab['max'] != float('inf') else f">{slab_min_display}",
                        'rate': slab['rate'],
                        'tax': round(tax_in_slab)
                    })
        
        # Calculate surcharge
        surcharge = 0
        for slab in cls.SURCHARGE_SLABS:
            if taxable_income >= slab['min'] and taxable_income < slab['max']:
                surcharge = (base_tax * slab['rate']) / 100
                break
        
        # Calculate cess
        cess = ((base_tax + surcharge) * cls.CESS_RATE) / 100
        
        # Total tax before rebate
        total_tax = base_tax + surcharge + cess
        
        # Apply rebate under section 87A
        rebate_info = cls.REBATE_87A[regime]
        rebate_applied = 0
        
        if taxable_income <= rebate_info['income_limit']:
            rebate_applied = min(total_tax, rebate_info['rebate'])
            total_tax = max(0, total_tax - rebate_applied)
        
        # Calculate deductions total
        total_deductions_applied = total_deductions + standard_ded if regime == 'old_regime' else standard_ded
        
        return {
            'grossIncome': round(gross_income),
            'deductions': round(total_deductions_applied),
            'taxableIncome': round(taxable_income),
            'baseTax': round(base_tax),
            'surcharge': round(surcharge),
            'cess': round(cess),
            'rebateApplied': round(rebate_applied),
            'totalTax': round(total_tax),
            'effectiveRate': round((total_tax / gross_income * 100), 2) if gross_income > 0 else 0,
            'breakdown': breakdown
        }

    @classmethod
    def compare_regimes(cls, gross_income: float, total_deductions: float) -> Dict[str, Any]:
        new_regime_calc = cls.calculate_tax(gross_income, 0, 'new_regime')
        old_regime_calc = cls.calculate_tax(gross_income, total_deductions, 'old_regime')
        
        savings = old_regime_calc['totalTax'] - new_regime_calc['totalTax']
        recommended = 'new_regime' if savings > 0 else 'old_regime'
        
        return {
            'new_regime': new_regime_calc,
            'old_regime': old_regime_calc,
            'savings': round(abs(savings)),
            'recommended': recommended
        }
