from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from datetime import datetime

class DocumentUploadResponse(BaseModel):
    document_id: str
    filename: str
    file_size: int
    mime_type: str
    uploaded_at: datetime = Field(default_factory=datetime.utcnow)

class DocumentAnalysisResult(BaseModel):
    analysis_id: str
    document_ids: List[str]
    extracted_data: Dict[str, Any]
    tax_calculation: Optional[Dict[str, Any]] = None
    analyzed_at: datetime = Field(default_factory=datetime.utcnow)

class TransactionCategorizationRequest(BaseModel):
    transactions: List[Dict[str, Any]]
