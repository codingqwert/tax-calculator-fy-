from pydantic import BaseModel, Field
from typing import Dict, Any, Optional, List
from datetime import datetime
import uuid

class TaxCalculation(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    calculation_type: str
    input_data: Dict[str, Any]
    result: Dict[str, Any]
    created_at: datetime = Field(default_factory=datetime.utcnow)
    user_identifier: Optional[str] = None

class IncomeInput(BaseModel):
    salary: float = 0
    business: float = 0
    other: float = 0

class DeductionsInput(BaseModel):
    section80C: float = 0
    section80CCD1B: float = 0
    section80D: float = 0
    section80DParents: float = 0
    hra: float = 0
    homeLoan: float = 0
    section80E: float = 0
    section80G: float = 0

class IncomeTaxRequest(BaseModel):
    income: IncomeInput
    deductions: DeductionsInput
    regime: str = "new"

class CapitalGainsRequest(BaseModel):
    assetType: str
    holdingPeriod: str
    purchasePrice: float
    salePrice: float
    purchaseDate: Optional[str] = None
    saleDate: Optional[str] = None
    indexation: bool = False

class TDSRequest(BaseModel):
    tdsType: str
    amount: float
    panAvailable: bool = True
    taxableIncome: float = 0
