from fastapi import APIRouter, HTTPException, Depends
from models.tax_calculation import (
    IncomeTaxRequest, CapitalGainsRequest, TDSRequest, TaxCalculation
)
from services.income_tax_service import IncomeTaxService
from services.capital_gains_service import CapitalGainsService
from services.tds_service import TDSService
from motor.motor_asyncio import AsyncIOMotorDatabase
from typing import List

router = APIRouter(tags=["tax"])

# Dependency to get database
async def get_db():
    from server import db
    return db

@router.post("/api/calculate-income-tax")
async def calculate_income_tax(request: IncomeTaxRequest, db: AsyncIOMotorDatabase = Depends(get_db)):
    try:
        # Calculate total income
        gross_income = request.income.salary + request.income.business + request.income.other
        
        # Calculate total deductions
        total_deductions = (
            request.deductions.section80C +
            request.deductions.section80CCD1B +
            request.deductions.section80D +
            request.deductions.section80DParents +
            request.deductions.hra +
            request.deductions.homeLoan +
            request.deductions.section80E +
            request.deductions.section80G
        )
        
        # Validate regime
        regime = 'new_regime' if request.regime == 'new' else 'old_regime'
        
        # Calculate tax
        result = IncomeTaxService.calculate_tax(gross_income, total_deductions, regime)
        
        # Save to database
        calculation = TaxCalculation(
            calculation_type='income_tax',
            input_data=request.dict(),
            result=result
        )
        await db.tax_calculations.insert_one(calculation.dict())
        
        return {
            'success': True,
            'data': result
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/api/compare-regimes")
async def compare_regimes(request: IncomeTaxRequest, db: AsyncIOMotorDatabase = Depends(get_db)):
    try:
        # Calculate total income
        gross_income = request.income.salary + request.income.business + request.income.other
        
        # Calculate total deductions
        total_deductions = (
            request.deductions.section80C +
            request.deductions.section80CCD1B +
            request.deductions.section80D +
            request.deductions.section80DParents +
            request.deductions.hra +
            request.deductions.homeLoan +
            request.deductions.section80E +
            request.deductions.section80G
        )
        
        # Compare both regimes
        comparison = IncomeTaxService.compare_regimes(gross_income, total_deductions)
        
        # Save to database
        calculation = TaxCalculation(
            calculation_type='regime_comparison',
            input_data=request.dict(),
            result=comparison
        )
        await db.tax_calculations.insert_one(calculation.dict())
        
        return {
            'success': True,
            'data': comparison
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/api/calculate-capital-gains")
async def calculate_capital_gains(request: CapitalGainsRequest, db: AsyncIOMotorDatabase = Depends(get_db)):
    try:
        result = CapitalGainsService.calculate_capital_gains_tax(
            asset_type=request.assetType,
            holding_period=request.holdingPeriod,
            purchase_price=request.purchasePrice,
            sale_price=request.salePrice,
            indexation=request.indexation
        )
        
        # Save to database
        calculation = TaxCalculation(
            calculation_type='capital_gains',
            input_data=request.dict(),
            result=result
        )
        await db.tax_calculations.insert_one(calculation.dict())
        
        return {
            'success': True,
            'data': result
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/api/calculate-tds")
async def calculate_tds(request: TDSRequest, db: AsyncIOMotorDatabase = Depends(get_db)):
    try:
        result = TDSService.calculate_tds(
            tds_type=request.tdsType,
            amount=request.amount,
            pan_available=request.panAvailable,
            taxable_income=request.taxableIncome
        )
        
        # Save to database
        calculation = TaxCalculation(
            calculation_type='tds',
            input_data=request.dict(),
            result=result
        )
        await db.tax_calculations.insert_one(calculation.dict())
        
        return {
            'success': True,
            'data': result
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/api/calculation-history")
async def get_calculation_history(type: str = None, limit: int = 10, db: AsyncIOMotorDatabase = Depends(get_db)):
    try:
        query = {}
        if type:
            query['calculation_type'] = type
        
        calculations = await db.tax_calculations.find(query).sort('created_at', -1).limit(limit).to_list(limit)
        
        return {
            'success': True,
            'data': calculations,
            'count': len(calculations)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
