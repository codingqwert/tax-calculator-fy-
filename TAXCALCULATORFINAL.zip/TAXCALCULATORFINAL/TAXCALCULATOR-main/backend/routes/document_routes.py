from fastapi import APIRouter, UploadFile, File, HTTPException, Depends, Form
from typing import List, Dict, Any
from models.document_upload import DocumentAnalysisResult, TransactionCategorizationRequest
from models.tax_calculation import TaxCalculation
from services.document_analysis_service import DocumentAnalysisService
from services.income_tax_service import IncomeTaxService
from motor.motor_asyncio import AsyncIOMotorDatabase
import os
import uuid
from pathlib import Path
import logging

router = APIRouter(tags=["documents"])
logger = logging.getLogger(__name__)

# Create upload directory (local-friendly)
UPLOAD_DIR = (Path(__file__).parent.parent / "uploads").resolve()
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# Dependency to get database
async def get_db():
    from server import db
    return db

@router.post("/api/upload-documents")
async def upload_documents(
    files: List[UploadFile] = File(...),
    db: AsyncIOMotorDatabase = Depends(get_db)
):
    """
    Upload multiple financial documents (PDFs, images, etc.)
    """
    try:
        uploaded_files = []
        
        for file in files:
            # Generate unique filename
            file_id = str(uuid.uuid4())
            file_extension = Path(file.filename).suffix
            saved_filename = f"{file_id}{file_extension}"
            file_path = UPLOAD_DIR / saved_filename
            
            # Save file
            content = await file.read()
            with open(file_path, "wb") as f:
                f.write(content)
            
            # Determine mime type
            mime_type = file.content_type or 'application/octet-stream'
            
            # Store metadata in database
            file_metadata = {
                'document_id': file_id,
                'original_filename': file.filename,
                'saved_filename': saved_filename,
                'file_path': str(file_path),
                'file_size': len(content),
                'mime_type': mime_type,
                'uploaded_at': None  # Will be set by MongoDB
            }
            
            await db.uploaded_documents.insert_one(file_metadata)
            
            uploaded_files.append({
                'document_id': file_id,
                'filename': file.filename,
                'file_size': len(content),
                'mime_type': mime_type
            })
        
        return {
            'success': True,
            'message': f'Successfully uploaded {len(uploaded_files)} documents',
            'documents': uploaded_files
        }
        
    except Exception as e:
        logger.error(f"File upload error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/api/analyze-documents")
async def analyze_documents(
    document_ids: List[str] = Form(...),
    db: AsyncIOMotorDatabase = Depends(get_db)
):
    """
    Analyze uploaded documents using AI to extract tax-relevant information
    """
    try:
        # Retrieve document paths from database
        documents = []
        for doc_id in document_ids:
            doc = await db.uploaded_documents.find_one({'document_id': doc_id})
            if not doc:
                raise HTTPException(status_code=404, detail=f"Document {doc_id} not found")
            documents.append(doc)
        
        # Extract file paths and mime types
        file_paths = [doc['file_path'] for doc in documents]
        mime_types = [doc['mime_type'] for doc in documents]
        
        # Analyze documents using AI
        analysis_service = DocumentAnalysisService()
        analysis_result = await analysis_service.analyze_financial_documents(file_paths, mime_types)
        
        if not analysis_result.get('success'):
            raise HTTPException(status_code=500, detail=analysis_result.get('error', 'Analysis failed'))
        
        extracted_data = analysis_result['data']
        
        # Calculate tax based on extracted data
        income_data = extracted_data.get('income', {})
        deductions_data = extracted_data.get('deductions', {})
        
        gross_income = (
            income_data.get('salary', 0) +
            income_data.get('business', 0) +
            income_data.get('other', 0)
        )
        
        total_deductions = sum([
            deductions_data.get('section80C', 0),
            deductions_data.get('section80CCD1B', 0),
            deductions_data.get('section80D', 0),
            deductions_data.get('section80DParents', 0),
            deductions_data.get('hra', 0),
            deductions_data.get('homeLoan', 0),
            deductions_data.get('section80E', 0),
            deductions_data.get('section80G', 0)
        ])
        
        # Calculate tax for both regimes
        tax_comparison = IncomeTaxService.compare_regimes(gross_income, total_deductions)
        
        # Adjust for TDS already paid
        tds_paid = extracted_data.get('tds_paid', {}).get('total', 0)
        tax_comparison['tds_paid'] = tds_paid
        tax_comparison['new_regime']['tax_payable'] = max(0, tax_comparison['new_regime']['totalTax'] - tds_paid)
        tax_comparison['old_regime']['tax_payable'] = max(0, tax_comparison['old_regime']['totalTax'] - tds_paid)
        
        # Save analysis result
        analysis_id = str(uuid.uuid4())
        analysis_record = {
            'analysis_id': analysis_id,
            'document_ids': document_ids,
            'extracted_data': extracted_data,
            'tax_calculation': tax_comparison,
            'analyzed_at': None  # MongoDB will set timestamp
        }
        
        await db.document_analyses.insert_one(analysis_record)
        
        return {
            'success': True,
            'analysis_id': analysis_id,
            'extracted_data': extracted_data,
            'tax_calculation': tax_comparison,
            'message': 'Documents analyzed successfully. Please review and verify the extracted data.'
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Document analysis error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/api/categorize-transactions")
async def categorize_transactions(
    request: TransactionCategorizationRequest,
    db: AsyncIOMotorDatabase = Depends(get_db)
):
    """
    Use AI to categorize transactions for tax purposes
    """
    try:
        analysis_service = DocumentAnalysisService()
        result = await analysis_service.categorize_transactions(request.transactions)
        
        if not result.get('success'):
            raise HTTPException(status_code=500, detail=result.get('error', 'Categorization failed'))
        
        return {
            'success': True,
            'data': result['data']
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Transaction categorization error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/api/document-analyses/{analysis_id}")
async def get_analysis(
    analysis_id: str,
    db: AsyncIOMotorDatabase = Depends(get_db)
):
    """
    Retrieve a saved document analysis
    """
    try:
        analysis = await db.document_analyses.find_one({'analysis_id': analysis_id})
        
        if not analysis:
            raise HTTPException(status_code=404, detail="Analysis not found")
        
        # Remove MongoDB _id field
        analysis.pop('_id', None)
        
        return {
            'success': True,
            'data': analysis
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving analysis: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/api/document-analyses")
async def list_analyses(
    limit: int = 10,
    db: AsyncIOMotorDatabase = Depends(get_db)
):
    """
    List recent document analyses
    """
    try:
        analyses = await db.document_analyses.find().sort('analyzed_at', -1).limit(limit).to_list(limit)
        
        # Remove MongoDB _id fields
        for analysis in analyses:
            analysis.pop('_id', None)
        
        return {
            'success': True,
            'data': analyses,
            'count': len(analyses)
        }
        
    except Exception as e:
        logger.error(f"Error listing analyses: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
