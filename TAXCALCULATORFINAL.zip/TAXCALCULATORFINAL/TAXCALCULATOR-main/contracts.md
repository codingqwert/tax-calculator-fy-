# Tax Calculator Backend Integration Contracts

## A) API Contracts

### 1. Income Tax Calculation API
**Endpoint:** `POST /api/calculate-income-tax`
**Request Body:**
```json
{
  "income": {
    "salary": 1500000,
    "business": 300000,
    "other": 0
  },
  "deductions": {
    "section80C": 150000,
    "section80CCD1B": 50000,
    "section80D": 25000,
    "section80DParents": 0,
    "hra": 0,
    "homeLoan": 0,
    "section80E": 0,
    "section80G": 0
  },
  "regime": "new"
}
```
**Response:**
```json
{
  "success": true,
  "data": {
    "grossIncome": 1800000,
    "deductions": 75000,
    "taxableIncome": 1725000,
    "baseTax": 262500,
    "surcharge": 0,
    "cess": 10500,
    "totalTax": 273000,
    "effectiveRate": "15.17",
    "breakdown": {
      "slabs": [
        {"range": "0-3L", "tax": 0},
        {"range": "3-7L", "tax": 20000},
        {"range": "7-10L", "tax": 30000},
        {"range": "10-12L", "tax": 30000},
        {"range": "12-15L", "tax": 60000},
        {"range": ">15L", "tax": 122500}
      ]
    }
  }
}
```

### 2. Capital Gains Calculation API
**Endpoint:** `POST /api/calculate-capital-gains`
**Request Body:**
```json
{
  "assetType": "equity",
  "holdingPeriod": "long",
  "purchasePrice": 500000,
  "salePrice": 1200000,
  "purchaseDate": "2022-01-15",
  "saleDate": "2024-03-20",
  "indexation": false
}
```
**Response:**
```json
{
  "success": true,
  "data": {
    "gains": 700000,
    "exemptionAmount": 125000,
    "taxableGain": 575000,
    "taxRate": 12.5,
    "baseTax": 71875,
    "cess": 2875,
    "totalTax": 74750,
    "netProceeds": 625250
  }
}
```

### 3. TDS Calculation API
**Endpoint:** `POST /api/calculate-tds`
**Request Body:**
```json
{
  "tdsType": "rent_194I",
  "amount": 300000,
  "panAvailable": true,
  "taxableIncome": 800000
}
```
**Response:**
```json
{
  "success": true,
  "data": {
    "amount": 300000,
    "tdsRate": 10,
    "tdsAmount": 30000,
    "netAmount": 270000,
    "threshold": 240000,
    "description": "TDS on rent payments exceeding ₹2,40,000 per year",
    "applicable": true
  }
}
```

### 4. Save Calculation History API
**Endpoint:** `POST /api/save-calculation`
**Request Body:**
```json
{
  "calculationType": "income_tax",
  "inputData": {...},
  "result": {...}
}
```

### 5. Get Calculation History API
**Endpoint:** `GET /api/calculation-history?type=income_tax&limit=10`

## B) Mock Data to Replace

**File: `/app/frontend/src/mock.js`**
- `mockCalculateTax()` - Will be replaced with actual API call to `/api/calculate-income-tax`
- All constant data (tax slabs, rates) will remain in frontend for reference
- Calculation logic will move to backend

## C) Backend Implementation Plan

### Models (MongoDB)

1. **TaxCalculation Model**
```python
{
  "_id": ObjectId,
  "calculation_type": "income_tax" | "capital_gains" | "tds",
  "input_data": Object,
  "result": Object,
  "created_at": DateTime,
  "user_identifier": String (optional - for future user tracking)
}
```

### Services

1. **IncomeTaxService** (`/app/backend/services/income_tax_service.py`)
   - Calculate tax for both regimes
   - Apply surcharge based on income
   - Apply cess (4%)
   - Apply rebate under section 87A
   - Return detailed breakdown

2. **CapitalGainsService** (`/app/backend/services/capital_gains_service.py`)
   - Calculate STCG/LTCG based on asset type and holding period
   - Apply indexation for eligible cases
   - Calculate tax with cess

3. **TDSService** (`/app/backend/services/tds_service.py`)
   - Calculate TDS based on type
   - Apply threshold checks
   - Handle PAN availability

### API Endpoints (`/app/backend/routes/`)

- `tax_routes.py` - All tax calculation endpoints
- Error handling for invalid inputs
- Input validation using Pydantic models

## D) Frontend-Backend Integration

### Changes Required in Frontend:

1. **Create API service file:** `/app/frontend/src/services/taxApi.js`
   - Replace `mockCalculateTax()` calls with actual API calls
   - Add error handling and loading states

2. **Update Components:**
   - `IncomeTaxCalculator.jsx` - Add loading state, replace mock call with API
   - `CapitalGainsCalculator.jsx` - Add loading state, replace mock calculations
   - `TDSCalculator.jsx` - Add loading state, replace mock calculations

3. **Error Handling:**
   - Add toast notifications for API errors
   - Display user-friendly error messages

### Integration Steps:
1. Keep mock.js for constants (tax slabs, rates, limits)
2. Create taxApi.js service layer
3. Update components to use API calls instead of mock functions
4. Add loading states and error handling
5. Test each calculator individually

## E) Data Flow

```
User Input → Frontend Component → API Service (taxApi.js) → 
Backend API → Service Layer (calculation logic) → 
MongoDB (save history) → Response → Frontend Display
```

## F) Tax Calculation Logic (Backend)

### Income Tax Calculation Algorithm:
1. Calculate total gross income
2. Apply standard deduction (₹75k new, ₹50k old)
3. Subtract eligible deductions (old regime only)
4. Calculate taxable income
5. Apply tax slabs to calculate base tax
6. Calculate surcharge (if income > ₹50L)
7. Calculate cess (4% on tax + surcharge)
8. Apply rebate under 87A if eligible
9. Return final tax liability

### Capital Gains Logic:
1. Calculate gains (sale - purchase)
2. Check holding period → STCG vs LTCG
3. Apply exemption (LTCG equity: ₹1.25L)
4. Apply tax rate based on asset type
5. Calculate cess
6. Return net proceeds

### TDS Logic:
1. Check threshold for TDS applicability
2. Determine rate based on section and PAN availability
3. Calculate TDS amount
4. Return net payable amount
