import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import IncomeTaxCalculator from '../components/IncomeTaxCalculator';
import CapitalGainsCalculator from '../components/CapitalGainsCalculator';
import TDSCalculator from '../components/TDSCalculator';
import DocumentUploadAnalyzer from '../components/DocumentUploadAnalyzer';
import { Calculator, TrendingUp, Receipt, FileUp } from 'lucide-react';

const TaxCalculator = () => {
  const [extractedData, setExtractedData] = useState(null);

  const handleAnalysisComplete = (analysisResult) => {
    setExtractedData(analysisResult);
    // You can switch to income tax tab here if needed
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex justify-center items-center gap-3 mb-4">
            <Calculator className="w-12 h-12 text-emerald-600" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
              Indian Tax Calculator 2025-26
            </h1>
          </div>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Comprehensive tax planning tool for Income Tax, Capital Gains, TDS & Document Analysis (Budget 2025)
          </p>
        </div>

        {/* Main Calculator Tabs */}
        <Tabs defaultValue="document" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8 max-w-3xl mx-auto h-auto">
            <TabsTrigger value="document" className="flex items-center gap-2 py-3">
              <FileUp className="w-4 h-4" />
              <span className="hidden sm:inline">Documents</span>
              <span className="sm:hidden">Docs</span>
            </TabsTrigger>
            <TabsTrigger value="income" className="flex items-center gap-2 py-3">
              <Calculator className="w-4 h-4" />
              <span className="hidden sm:inline">Income Tax</span>
              <span className="sm:hidden">Income</span>
            </TabsTrigger>
            <TabsTrigger value="capital" className="flex items-center gap-2 py-3">
              <TrendingUp className="w-4 h-4" />
              <span className="hidden sm:inline">Capital Gains</span>
              <span className="sm:hidden">Gains</span>
            </TabsTrigger>
            <TabsTrigger value="tds" className="flex items-center gap-2 py-3">
              <Receipt className="w-4 h-4" />
              <span className="hidden sm:inline">TDS Calculator</span>
              <span className="sm:hidden">TDS</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="document">
            <DocumentUploadAnalyzer onAnalysisComplete={handleAnalysisComplete} />
          </TabsContent>

          <TabsContent value="income">
            <IncomeTaxCalculator extractedData={extractedData} />
          </TabsContent>

          <TabsContent value="capital">
            <CapitalGainsCalculator />
          </TabsContent>

          <TabsContent value="tds">
            <TDSCalculator />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default TaxCalculator;
