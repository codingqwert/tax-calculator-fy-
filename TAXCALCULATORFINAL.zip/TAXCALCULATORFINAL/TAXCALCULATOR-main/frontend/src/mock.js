// Mock data for tax calculations

// Tax slabs for Budget 2025 (AY 2026-27)
export const TAX_SLABS_2025_26 = {
  new_regime: [
    { min: 0, max: 400000, rate: 0 },
    { min: 400000, max: 800000, rate: 5 },
    { min: 800000, max: 1200000, rate: 10 },
    { min: 1200000, max: 1600000, rate: 15 },
    { min: 1600000, max: 2000000, rate: 20 },
    { min: 2000000, max: 2400000, rate: 25 },
    { min: 2400000, max: Infinity, rate: 30 }
  ],
  old_regime: [
    { min: 0, max: 250000, rate: 0 },
    { min: 250000, max: 500000, rate: 5 },
    { min: 500000, max: 1000000, rate: 20 },
    { min: 1000000, max: Infinity, rate: 30 }
  ]
};

export const SURCHARGE_SLABS = [
  { min: 5000000, max: 10000000, rate: 10 },
  { min: 10000000, max: 20000000, rate: 15 },
  { min: 20000000, max: 50000000, rate: 25 },
  { min: 50000000, max: Infinity, rate: 37 }
];

export const CESS_RATE = 4; // Health and Education Cess

export const STANDARD_DEDUCTION = {
  new_regime: 75000,
  old_regime: 50000
};

export const DEDUCTION_LIMITS = {
  section_80C: 150000,
  section_80CCD_1B: 50000,
  section_80D_self: 25000,
  section_80D_senior: 50000,
  section_80D_parents: 25000,
  section_80D_parents_senior: 50000,
  section_80TTA: 10000,
  section_80TTB: 50000,
  section_80G: null, // Variable based on donation
  section_80E: null, // No limit
  section_24: 200000 // Home loan interest
};

export const REBATE_87A = {
  new_regime: { income_limit: 1200000, rebate: 60000 },
  old_regime: { income_limit: 500000, rebate: 12500 }
};

export const CAPITAL_GAINS_RATES = {
  STCG_equity: 20, // Listed equity/mutual funds (Budget 2025)
  STCG_other: null, // Added to income
  LTCG_equity: 12.5, // Above 1.25 lakhs (Budget 2025)
  LTCG_equity_exemption: 125000,
  LTCG_other: 12.5, // No indexation from July 23, 2024 (Budget 2025)
};

export const TDS_RATES = {
  salary: 'As per slab',
  rent_194I: 10,
  professional_194J: 10,
  contract_194C_individual: 1,
  contract_194C_company: 2,
  commission_194H: 5,
  interest_194A: 10,
  dividend_194: 10,
  lottery_194B: 30
};

// TDS Thresholds (Budget 2025)
export const TDS_THRESHOLDS = {
  rent_194I: 600000, // ₹50,000 per month (₹6,00,000 annual)
  professional_194J: 30000,
  contract_194C: 30000,
  commission_194H: 15000,
  interest_194A: 40000,
  dividend_194: 5000,
  lottery_194B: 10000
};

export const mockCalculateTax = (income, deductions, regime) => {
  // This is a mock function that will be replaced with actual API call
  const slabs = regime === 'new' ? TAX_SLABS_2025_26.new_regime : TAX_SLABS_2025_26.old_regime;
  const standardDed = regime === 'new' ? STANDARD_DEDUCTION.new_regime : STANDARD_DEDUCTION.old_regime;
  
  let taxableIncome = income - standardDed;
  
  if (regime === 'old') {
    taxableIncome -= deductions;
  }
  
  let tax = 0;
  for (const slab of slabs) {
    if (taxableIncome > slab.min) {
      const taxableAmount = Math.min(taxableIncome, slab.max) - slab.min;
      tax += (taxableAmount * slab.rate) / 100;
    }
  }
  
  // Apply surcharge
  let surcharge = 0;
  for (const slab of SURCHARGE_SLABS) {
    if (taxableIncome >= slab.min && taxableIncome < slab.max) {
      surcharge = (tax * slab.rate) / 100;
      break;
    }
  }
  
  const cess = ((tax + surcharge) * CESS_RATE) / 100;
  const totalTax = tax + surcharge + cess;
  
  // Apply rebate (Budget 2025 - ₹60,000 rebate for income up to ₹12L in new regime)
  const rebateLimit = regime === 'new' ? REBATE_87A.new_regime.income_limit : REBATE_87A.old_regime.income_limit;
  const rebateAmount = regime === 'new' ? REBATE_87A.new_regime.rebate : REBATE_87A.old_regime.rebate;
  
  const finalTax = taxableIncome <= rebateLimit ? Math.max(0, totalTax - rebateAmount) : totalTax;
  
  return {
    grossIncome: income,
    deductions: regime === 'old' ? deductions + standardDed : standardDed,
    taxableIncome: Math.max(0, taxableIncome),
    baseTax: Math.round(tax),
    surcharge: Math.round(surcharge),
    cess: Math.round(cess),
    totalTax: Math.round(finalTax),
    effectiveRate: income > 0 ? ((finalTax / income) * 100).toFixed(2) : 0
  };
};
