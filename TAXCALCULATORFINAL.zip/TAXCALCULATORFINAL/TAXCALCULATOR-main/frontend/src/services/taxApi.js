import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8000';
const API = `${BACKEND_URL}/api`;

export const taxApi = {
  // Calculate income tax
  calculateIncomeTax: async (income, deductions, regime) => {
    try {
      const response = await axios.post(`${API}/calculate-income-tax`, {
        income,
        deductions,
        regime
      });
      return response.data;
    } catch (error) {
      console.error('Error calculating income tax:', error);
      throw error;
    }
  },

  // Compare tax regimes
  compareRegimes: async (income, deductions) => {
    try {
      const response = await axios.post(`${API}/compare-regimes`, {
        income,
        deductions,
        regime: 'new' // Will calculate both
      });
      return response.data;
    } catch (error) {
      console.error('Error comparing regimes:', error);
      throw error;
    }
  },

  // Calculate capital gains
  calculateCapitalGains: async (assetType, holdingPeriod, purchasePrice, salePrice, purchaseDate, saleDate, indexation) => {
    try {
      const response = await axios.post(`${API}/calculate-capital-gains`, {
        assetType,
        holdingPeriod,
        purchasePrice,
        salePrice,
        purchaseDate,
        saleDate,
        indexation
      });
      return response.data;
    } catch (error) {
      console.error('Error calculating capital gains:', error);
      throw error;
    }
  },

  // Calculate TDS
  calculateTDS: async (tdsType, amount, panAvailable, taxableIncome) => {
    try {
      const response = await axios.post(`${API}/calculate-tds`, {
        tdsType,
        amount,
        panAvailable,
        taxableIncome
      });
      return response.data;
    } catch (error) {
      console.error('Error calculating TDS:', error);
      throw error;
    }
  },

  // Get calculation history
  getCalculationHistory: async (type = null, limit = 10) => {
    try {
      const params = new URLSearchParams();
      if (type) params.append('type', type);
      params.append('limit', limit);
      
      const response = await axios.get(`${API}/calculation-history?${params.toString()}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching calculation history:', error);
      throw error;
    }
  }
};
