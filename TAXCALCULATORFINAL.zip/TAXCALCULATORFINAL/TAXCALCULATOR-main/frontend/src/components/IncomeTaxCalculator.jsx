import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Switch } from './ui/switch';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { taxApi } from '../services/taxApi';
import { useToast } from '../hooks/use-toast';
import { ArrowRight, IndianRupee, PiggyBank, FileText, TrendingDown, Calculator, Loader2 } from 'lucide-react';

const IncomeTaxCalculator = () => {
  const { toast } = useToast();
  const [regime, setRegime] = useState('new');
  const [loading, setLoading] = useState(false);
  const [income, setIncome] = useState({
    salary: '',
    business: '',
    other: ''
  });
  
  const [deductions, setDeductions] = useState({
    section80C: '',
    section80CCD1B: '',
    section80D: '',
    section80DParents: '',
    hra: '',
    homeLoan: '',
    section80E: '',
    section80G: ''
  });

  const [showComparison, setShowComparison] = useState(false);
  const [taxCalculation, setTaxCalculation] = useState(null);
  const [comparisonData, setComparisonData] = useState(null);

  const totalIncome = useMemo(() => {
    return (
      parseFloat(income.salary || 0) +
      parseFloat(income.business || 0) +
      parseFloat(income.other || 0)
    );
  }, [income]);

  const totalDeductions = useMemo(() => {
    return Object.values(deductions).reduce((sum, val) => sum + parseFloat(val || 0), 0);
  }, [deductions]);

  const handleCalculate = async () => {
    if (totalIncome === 0) {
      toast({
        title: "Error",
        description: "Please enter income details",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      // Prepare income and deductions data
      const incomeData = {
        salary: parseFloat(income.salary || 0),
        business: parseFloat(income.business || 0),
        other: parseFloat(income.other || 0)
      };

      const deductionsData = {
        section80C: parseFloat(deductions.section80C || 0),
        section80CCD1B: parseFloat(deductions.section80CCD1B || 0),
        section80D: parseFloat(deductions.section80D || 0),
        section80DParents: parseFloat(deductions.section80DParents || 0),
        hra: parseFloat(deductions.hra || 0),
        homeLoan: parseFloat(deductions.homeLoan || 0),
        section80E: parseFloat(deductions.section80E || 0),
        section80G: parseFloat(deductions.section80G || 0)
      };

      // Get regime comparison
      const comparisonResponse = await taxApi.compareRegimes(incomeData, deductionsData);
      
      if (comparisonResponse.success) {
        setComparisonData({
          new: comparisonResponse.data.new_regime,
          old: comparisonResponse.data.old_regime,
          savings: comparisonResponse.data.savings,
          recommended: comparisonResponse.data.recommended
        });

        // Set the current regime calculation
        if (regime === 'new') {
          setTaxCalculation(comparisonResponse.data.new_regime);
        } else {
          setTaxCalculation(comparisonResponse.data.old_regime);
        }

        setShowComparison(true);
        
        toast({
          title: "Success",
          description: "Tax calculation completed successfully"
        });
      }
    } catch (error) {
      console.error('Error calculating tax:', error);
      toast({
        title: "Error",
        description: "Failed to calculate tax. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(value);
  };

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      {/* Input Section */}
      <div className="lg:col-span-2 space-y-6">
        {/* Regime Selector */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Select Tax Regime</span>
              <Badge variant={regime === 'new' ? 'default' : 'secondary'}>
                {regime === 'new' ? 'New Regime' : 'Old Regime'}
              </Badge>
            </CardTitle>
            <CardDescription>
              Choose between the new simplified regime or old regime with deductions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
              <Label htmlFor="regime-toggle" className="flex-1 cursor-pointer">
                <div className="font-semibold">New Regime (Lower rates, fewer deductions)</div>
                <div className="text-sm text-gray-600">Recommended for most taxpayers</div>
              </Label>
              <Switch
                id="regime-toggle"
                checked={regime === 'old'}
                onCheckedChange={(checked) => setRegime(checked ? 'old' : 'new')}
              />
              <Label htmlFor="regime-toggle" className="flex-1 cursor-pointer text-right">
                <div className="font-semibold">Old Regime (More deductions)</div>
                <div className="text-sm text-gray-600">For high deduction claims</div>
              </Label>
            </div>
          </CardContent>
        </Card>

        {/* Income Details */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <IndianRupee className="w-5 h-5 text-emerald-600" />
              Income Details
            </CardTitle>
            <CardDescription>Enter your total income from all sources</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="salary">Salary Income</Label>
                <Input
                  id="salary"
                  type="number"
                  placeholder="0"
                  value={income.salary}
                  onChange={(e) => setIncome({ ...income, salary: e.target.value })}
                  className="text-lg"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="business">Business/Profession</Label>
                <Input
                  id="business"
                  type="number"
                  placeholder="0"
                  value={income.business}
                  onChange={(e) => setIncome({ ...income, business: e.target.value })}
                  className="text-lg"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="other">Other Income</Label>
                <Input
                  id="other"
                  type="number"
                  placeholder="0"
                  value={income.other}
                  onChange={(e) => setIncome({ ...income, other: e.target.value })}
                  className="text-lg"
                />
              </div>
            </div>
            <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-200">
              <div className="flex justify-between items-center">
                <span className="font-semibold text-emerald-900">Total Gross Income:</span>
                <span className="text-2xl font-bold text-emerald-700">{formatCurrency(totalIncome)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Deductions - Only for Old Regime */}
        {regime === 'old' && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PiggyBank className="w-5 h-5 text-blue-600" />
                Deductions & Exemptions
              </CardTitle>
              <CardDescription>Claim deductions to reduce taxable income (Old Regime only)</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="80c" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="80c">80C/80D</TabsTrigger>
                  <TabsTrigger value="hra">HRA</TabsTrigger>
                  <TabsTrigger value="home">Home Loan</TabsTrigger>
                  <TabsTrigger value="other">Other</TabsTrigger>
                </TabsList>

                <TabsContent value="80c" className="space-y-4 mt-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="80c">Section 80C (Max: ₹1,50,000)</Label>
                      <Input
                        id="80c"
                        type="number"
                        placeholder="0"
                        value={deductions.section80C}
                        onChange={(e) => setDeductions({ ...deductions, section80C: e.target.value })}
                      />
                      <p className="text-xs text-gray-500">PPF, EPF, LIC, ELSS, Tax Saver FD</p>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="80ccd1b">Section 80CCD(1B) (Max: ₹50,000)</Label>
                      <Input
                        id="80ccd1b"
                        type="number"
                        placeholder="0"
                        value={deductions.section80CCD1B}
                        onChange={(e) => setDeductions({ ...deductions, section80CCD1B: e.target.value })}
                      />
                      <p className="text-xs text-gray-500">NPS additional contribution</p>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="80d">Section 80D - Self (Max: ₹25,000)</Label>
                      <Input
                        id="80d"
                        type="number"
                        placeholder="0"
                        value={deductions.section80D}
                        onChange={(e) => setDeductions({ ...deductions, section80D: e.target.value })}
                      />
                      <p className="text-xs text-gray-500">Health insurance premium</p>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="80d-parents">Section 80D - Parents (Max: ₹50,000)</Label>
                      <Input
                        id="80d-parents"
                        type="number"
                        placeholder="0"
                        value={deductions.section80DParents}
                        onChange={(e) => setDeductions({ ...deductions, section80DParents: e.target.value })}
                      />
                      <p className="text-xs text-gray-500">Parents' health insurance</p>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="hra" className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="hra">HRA Exemption</Label>
                    <Input
                      id="hra"
                      type="number"
                      placeholder="0"
                      value={deductions.hra}
                      onChange={(e) => setDeductions({ ...deductions, hra: e.target.value })}
                    />
                    <p className="text-xs text-gray-500">House Rent Allowance exemption amount</p>
                  </div>
                </TabsContent>

                <TabsContent value="home" className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="home-loan">Section 24 - Home Loan Interest (Max: ₹2,00,000)</Label>
                    <Input
                      id="home-loan"
                      type="number"
                      placeholder="0"
                      value={deductions.homeLoan}
                      onChange={(e) => setDeductions({ ...deductions, homeLoan: e.target.value })}
                    />
                    <p className="text-xs text-gray-500">Interest paid on home loan for self-occupied property</p>
                  </div>
                </TabsContent>

                <TabsContent value="other" className="space-y-4 mt-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="80e">Section 80E - Education Loan</Label>
                      <Input
                        id="80e"
                        type="number"
                        placeholder="0"
                        value={deductions.section80E}
                        onChange={(e) => setDeductions({ ...deductions, section80E: e.target.value })}
                      />
                      <p className="text-xs text-gray-500">No upper limit</p>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="80g">Section 80G - Donations</Label>
                      <Input
                        id="80g"
                        type="number"
                        placeholder="0"
                        value={deductions.section80G}
                        onChange={(e) => setDeductions({ ...deductions, section80G: e.target.value })}
                      />
                      <p className="text-xs text-gray-500">Eligible charitable donations</p>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>

              <Separator className="my-4" />
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="flex justify-between items-center">
                  <span className="font-semibold text-blue-900">Total Deductions:</span>
                  <span className="text-xl font-bold text-blue-700">{formatCurrency(totalDeductions)}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Calculate Button */}
        <Button 
          onClick={handleCalculate} 
          size="lg" 
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-6 text-lg"
          disabled={totalIncome === 0 || loading}
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 w-5 h-5 animate-spin" />
              Calculating...
            </>
          ) : (
            <>
              Calculate Tax & Compare Regimes
              <ArrowRight className="ml-2 w-5 h-5" />
            </>
          )}
        </Button>
      </div>

      {/* Results Section */}
      <div className="lg:col-span-1">
        {taxCalculation && showComparison && (
          <div className="space-y-6 sticky top-6">
            {/* Current Regime Tax */}
            <Card className="border-2 border-emerald-500">
              <CardHeader className="bg-gradient-to-br from-emerald-50 to-blue-50">
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  {regime === 'new' ? 'New Regime' : 'Old Regime'} Tax
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6 space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Gross Income:</span>
                  <span className="font-semibold">{formatCurrency(taxCalculation.grossIncome)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Deductions:</span>
                  <span className="font-semibold text-green-600">- {formatCurrency(taxCalculation.deductions)}</span>
                </div>
                <Separator />
                <div className="flex justify-between">
                  <span className="font-semibold">Taxable Income:</span>
                  <span className="font-bold">{formatCurrency(taxCalculation.taxableIncome)}</span>
                </div>
                <Separator />
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Base Tax:</span>
                  <span>{formatCurrency(taxCalculation.baseTax)}</span>
                </div>
                {taxCalculation.surcharge > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Surcharge:</span>
                    <span>{formatCurrency(taxCalculation.surcharge)}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Cess (4%):</span>
                  <span>{formatCurrency(taxCalculation.cess)}</span>
                </div>
                <Separator className="my-3" />
                <div className="p-4 bg-emerald-600 text-white rounded-lg">
                  <div className="text-sm opacity-90 mb-1">Total Tax Liability</div>
                  <div className="text-3xl font-bold">{formatCurrency(taxCalculation.totalTax)}</div>
                  <div className="text-sm opacity-90 mt-1">Effective Rate: {taxCalculation.effectiveRate}%</div>
                </div>
              </CardContent>
            </Card>

            {/* Comparison Card */}
            {comparisonData && (
              <Card className="border-2">
                <CardHeader className="bg-gradient-to-br from-blue-50 to-purple-50">
                  <CardTitle className="flex items-center gap-2">
                    <TrendingDown className="w-5 h-5" />
                    Regime Comparison
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6 space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium">New Regime:</span>
                      <span className="font-bold text-emerald-600">{formatCurrency(comparisonData.new.totalTax)}</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium">Old Regime:</span>
                      <span className="font-bold text-blue-600">{formatCurrency(comparisonData.old.totalTax)}</span>
                    </div>
                  </div>
                  <Separator />
                  <div className={`p-4 rounded-lg ${comparisonData.savings > 0 ? 'bg-green-50 border border-green-200' : 'bg-orange-50 border border-orange-200'}`}>
                    <div className="text-sm font-medium mb-1">
                      {comparisonData.savings > 0 ? 'You Save with New Regime:' : 'You Save with Old Regime:'}
                    </div>
                    <div className="text-2xl font-bold text-green-700">
                      {formatCurrency(Math.abs(comparisonData.savings))}
                    </div>
                  </div>
                  <div className="text-sm text-gray-600 mt-4 p-3 bg-blue-50 rounded-lg">
                    <strong>Recommendation:</strong> {comparisonData.savings > 0 ? 'New regime' : 'Old regime'} is better for your income and deductions.
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {(!taxCalculation || !showComparison) && (
          <Card className="border-2 border-dashed">
            <CardContent className="pt-6 text-center py-12">
              <Calculator className="w-16 h-16 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500">Enter your income details and click calculate to see tax breakdown</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default IncomeTaxCalculator;
