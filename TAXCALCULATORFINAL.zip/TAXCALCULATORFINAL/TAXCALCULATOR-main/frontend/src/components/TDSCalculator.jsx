import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { taxApi } from '../services/taxApi';
import { useToast } from '../hooks/use-toast';
import { Receipt, Building, User, FileText, Briefcase, TrendingUp, Loader2 } from 'lucide-react';

const TDSCalculator = () => {
  const { toast } = useToast();
  const [tdsType, setTdsType] = useState('salary');
  const [amount, setAmount] = useState('');
  const [panAvailable, setPanAvailable] = useState(true);
  const [taxableIncome, setTaxableIncome] = useState('');
  const [loading, setLoading] = useState(false);
  const [tdsCalculation, setTdsCalculation] = useState(null);

  const handleCalculate = async () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: "Error",
        description: "Please enter a valid amount",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const response = await taxApi.calculateTDS(
        tdsType,
        parseFloat(amount),
        panAvailable,
        parseFloat(taxableIncome || 0)
      );

      if (response.success) {
        setTdsCalculation(response.data);
        toast({
          title: "Success",
          description: "TDS calculated successfully"
        });
      }
    } catch (error) {
      console.error('Error calculating TDS:', error);
      toast({
        title: "Error",
        description: "Failed to calculate TDS. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(value);
  };

  const tdsCategories = [
    { value: 'salary', label: 'Salary (TDS on Employment)', icon: Briefcase, section: '' },
    { value: 'rent_194I', label: 'Rent Payment', icon: Building, section: '194-I' },
    { value: 'professional_194J', label: 'Professional/Technical Fees', icon: User, section: '194-J' },
    { value: 'contract_194C', label: 'Contract Payment', icon: FileText, section: '194-C' },
    { value: 'commission_194H', label: 'Commission/Brokerage', icon: Receipt, section: '194-H' },
    { value: 'interest_194A', label: 'Interest Income', icon: Building, section: '194-A' },
    { value: 'dividend_194', label: 'Dividend Income', icon: TrendingUp, section: '194' },
    { value: 'lottery_194B', label: 'Lottery/Game Winnings', icon: Receipt, section: '194-B' }
  ];

  const selectedCategory = tdsCategories.find(cat => cat.value === tdsType);

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      {/* Input Section */}
      <div className="lg:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Receipt className="w-6 h-6 text-purple-600" />
              TDS Calculator
            </CardTitle>
            <CardDescription>
              Calculate Tax Deducted at Source (TDS) for various types of payments
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* TDS Type Selection */}
            <div className="space-y-2">
              <Label>TDS Type/Section</Label>
              <Select value={tdsType} onValueChange={setTdsType}>
                <SelectTrigger className="text-base">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {tdsCategories.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      <div className="flex items-center justify-between w-full">
                        <span>{cat.label}</span>
                        {cat.section && (
                          <Badge variant="outline" className="ml-2">
                            Section {cat.section}
                          </Badge>
                        )}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Amount Input */}
            <div className="space-y-2">
              <Label htmlFor="amount">
                {tdsType === 'salary' ? 'Monthly Salary' : 'Payment Amount'}
              </Label>
              <Input
                id="amount"
                type="number"
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="text-lg"
              />
            </div>

            {/* Additional Fields for Salary TDS */}
            {tdsType === 'salary' && (
              <div className="space-y-2">
                <Label htmlFor="annual-income">Estimated Annual Taxable Income</Label>
                <Input
                  id="annual-income"
                  type="number"
                  placeholder="0"
                  value={taxableIncome}
                  onChange={(e) => setTaxableIncome(e.target.value)}
                  className="text-lg"
                />
                <p className="text-xs text-gray-500">
                  Enter annual taxable income after deductions (used to determine TDS rate)
                </p>
              </div>
            )}

            {/* PAN Availability */}
            {tdsType !== 'salary' && tdsType !== 'lottery_194B' && (
              <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base">Is PAN Available?</Label>
                    <p className="text-sm text-gray-600 mt-1">
                      TDS rate is higher (20%) if PAN is not provided
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant={panAvailable ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setPanAvailable(true)}
                    >
                      Yes
                    </Button>
                    <Button
                      variant={!panAvailable ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setPanAvailable(false)}
                    >
                      No
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {/* Info Card */}
            {tdsCalculation && (
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="flex items-start gap-2">
                  <FileText className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <div className="font-semibold text-blue-900 mb-1">
                      {selectedCategory?.label} - Section {selectedCategory?.section || 'TDS'}
                    </div>
                    <p className="text-sm text-blue-800">{tdsCalculation.description}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Calculate Button */}
            <Button
              onClick={handleCalculate}
              size="lg"
              className="w-full bg-purple-600 hover:bg-purple-700 text-white"
              disabled={!amount || parseFloat(amount) <= 0 || loading}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 w-5 h-5 animate-spin" />
                  Calculating...
                </>
              ) : (
                'Calculate TDS'
              )}
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Results Section */}
      <div className="lg:col-span-1">
        {tdsCalculation && parseFloat(amount) > 0 ? (
          <Card className="border-2 border-purple-500 sticky top-6">
            <CardHeader className="bg-gradient-to-br from-purple-50 to-pink-50">
              <CardTitle className="flex items-center gap-2">
                <Receipt className="w-5 h-5" />
                TDS Calculation
              </CardTitle>
              {selectedCategory?.section && (
                <Badge className="w-fit bg-purple-600">Section {selectedCategory.section}</Badge>
              )}
            </CardHeader>
            <CardContent className="pt-6 space-y-3">
              {tdsCalculation.threshold > 0 && (
                <>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Threshold Limit:</span>
                    <span className="font-semibold">{formatCurrency(tdsCalculation.threshold)}</span>
                  </div>
                  <Separator />
                </>
              )}

              <div className="flex justify-between">
                <span className="font-semibold">Gross Amount:</span>
                <span className="font-bold">{formatCurrency(tdsCalculation.amount)}</span>
              </div>

              <div className="p-3 bg-gray-50 rounded-lg">
                <div className="text-sm text-gray-600 mb-1">TDS Rate:</div>
                <div className="text-xl font-bold text-purple-600">{tdsCalculation.tdsRate}%</div>
                {!panAvailable && tdsType !== 'salary' && tdsType !== 'lottery_194B' && (
                  <div className="text-xs text-orange-600 mt-1">
                    Higher rate (No PAN)
                  </div>
                )}
              </div>

              <Separator />

              {tdsCalculation.applicable ? (
                <>
                  <div className="p-4 bg-red-50 rounded-lg border border-red-200">
                    <div className="text-sm text-red-900 mb-1">TDS to be Deducted:</div>
                    <div className="text-2xl font-bold text-red-700">
                      {formatCurrency(tdsCalculation.tdsAmount)}
                    </div>
                  </div>

                  <Separator className="my-3" />

                  <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                    <div className="text-sm text-green-900 mb-1">Net Amount Payable:</div>
                    <div className="text-2xl font-bold text-green-700">
                      {formatCurrency(tdsCalculation.netAmount)}
                    </div>
                  </div>
                </>
              ) : (
                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <div className="text-center">
                    <div className="text-green-700 font-semibold mb-1">No TDS Applicable</div>
                    <div className="text-sm text-green-600">
                      Amount is below threshold limit
                    </div>
                  </div>
                </div>
              )}

              {/* Important Notes */}
              <div className="mt-4 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                <div className="text-xs text-yellow-900">
                  <strong>Note:</strong> TDS deducted can be claimed as credit while filing ITR.
                  Ensure TDS is deposited and Form 26AS is updated.
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="border-2 border-dashed sticky top-6">
            <CardContent className="pt-6 text-center py-12">
              <Receipt className="w-16 h-16 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500">Enter payment details to calculate TDS</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default TDSCalculator;
