import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Progress } from './ui/progress';
import { useToast } from '../hooks/use-toast';
import { Upload, FileText, X, Loader2, CheckCircle2, AlertCircle, FileSpreadsheet, FileImage } from 'lucide-react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const DocumentUploadAnalyzer = ({ onAnalysisComplete }) => {
  const { toast } = useToast();
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [uploadedDocuments, setUploadedDocuments] = useState([]);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);

  const handleFileSelect = (event) => {
    const selectedFiles = Array.from(event.target.files);
    setFiles(prev => [...prev, ...selectedFiles]);
  };

  const removeFile = (index) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  const getFileIcon = (fileName) => {
    const extension = fileName.split('.').pop().toLowerCase();
    if (['pdf'].includes(extension)) return <FileText className="w-5 h-5" />;
    if (['png', 'jpg', 'jpeg'].includes(extension)) return <FileImage className="w-5 h-5" />;
    if (['xlsx', 'xls', 'csv'].includes(extension)) return <FileSpreadsheet className="w-5 h-5" />;
    return <FileText className="w-5 h-5" />;
  };

  const uploadDocuments = async () => {
    if (files.length === 0) {
      toast({
        title: "No files selected",
        description: "Please select at least one document to upload",
        variant: "destructive"
      });
      return;
    }

    setUploading(true);
    setUploadProgress(0);

    try {
      const formData = new FormData();
      files.forEach(file => {
        formData.append('files', file);
      });

      const response = await axios.post(`${API}/upload-documents`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        },
        onUploadProgress: (progressEvent) => {
          const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
          setUploadProgress(percentCompleted);
        }
      });

      if (response.data.success) {
        setUploadedDocuments(response.data.documents);
        toast({
          title: "Success",
          description: `${files.length} documents uploaded successfully`
        });
        setFiles([]);
      }
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: "Upload failed",
        description: error.response?.data?.detail || "Failed to upload documents",
        variant: "destructive"
      });
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };

  const analyzeDocuments = async () => {
    if (uploadedDocuments.length === 0) {
      toast({
        title: "No documents",
        description: "Please upload documents first",
        variant: "destructive"
      });
      return;
    }

    setAnalyzing(true);

    try {
      const documentIds = uploadedDocuments.map(doc => doc.document_id);
      const formData = new FormData();
      documentIds.forEach(id => formData.append('document_ids', id));

      const response = await axios.post(`${API}/analyze-documents`, formData, {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      });

      if (response.data.success) {
        setAnalysisResult(response.data);
        
        toast({
          title: "Analysis complete",
          description: "Documents analyzed successfully. Please review the extracted data."
        });

        // Pass result to parent component
        if (onAnalysisComplete) {
          onAnalysisComplete(response.data);
        }
      }
    } catch (error) {
      console.error('Analysis error:', error);
      toast({
        title: "Analysis failed",
        description: error.response?.data?.detail || "Failed to analyze documents",
        variant: "destructive"
      });
    } finally {
      setAnalyzing(false);
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(value);
  };

  return (
    <div className="space-y-6">
      {/* Upload Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="w-6 h-6 text-purple-600" />
            Upload Financial Documents
          </CardTitle>
          <CardDescription>
            Upload bank statements, Form 16, investment proofs, rent receipts, medical bills, etc. (PDF, JPG, PNG supported)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* File Input */}
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-purple-500 transition-colors">
            <input
              type="file"
              multiple
              accept=".pdf,.png,.jpg,.jpeg,.xlsx,.csv"
              onChange={handleFileSelect}
              className="hidden"
              id="file-upload"
            />
            <label htmlFor="file-upload" className="cursor-pointer">
              <Upload className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <p className="text-lg font-medium text-gray-700">Click to upload or drag and drop</p>
              <p className="text-sm text-gray-500 mt-1">PDF, PNG, JPG, XLSX, CSV up to 10MB each</p>
            </label>
          </div>

          {/* Selected Files */}
          {files.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Selected Files ({files.length})</span>
                <Button variant="outline" size="sm" onClick={() => setFiles([])}>
                  Clear All
                </Button>
              </div>
              <div className="max-h-40 overflow-y-auto space-y-2">
                {files.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      {getFileIcon(file.name)}
                      <div>
                        <p className="text-sm font-medium text-gray-900">{file.name}</p>
                        <p className="text-xs text-gray-500">{(file.size / 1024).toFixed(2)} KB</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => removeFile(index)}>
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Upload Progress */}
          {uploading && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Uploading...</span>
                <span>{uploadProgress}%</span>
              </div>
              <Progress value={uploadProgress} className="h-2" />
            </div>
          )}

          {/* Upload Button */}
          <Button
            onClick={uploadDocuments}
            disabled={files.length === 0 || uploading}
            className="w-full bg-purple-600 hover:bg-purple-700"
            size="lg"
          >
            {uploading ? (
              <>
                <Loader2 className="mr-2 w-5 h-5 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Upload className="mr-2 w-5 h-5" />
                Upload Documents
              </>
            )}
          </Button>

          {/* Uploaded Documents */}
          {uploadedDocuments.length > 0 && (
            <div className="space-y-2 pt-4 border-t">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                <span className="text-sm font-medium text-green-700">
                  {uploadedDocuments.length} documents uploaded successfully
                </span>
              </div>
              <Button
                onClick={analyzeDocuments}
                disabled={analyzing}
                className="w-full bg-emerald-600 hover:bg-emerald-700"
                size="lg"
              >
                {analyzing ? (
                  <>
                    <Loader2 className="mr-2 w-5 h-5 animate-spin" />
                    Analyzing with AI...
                  </>
                ) : (
                  'Analyze Documents & Calculate Tax'
                )}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Analysis Results */}
      {analysisResult && (
        <Card className="border-2 border-emerald-500">
          <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="w-6 h-6 text-emerald-600" />
              Analysis Complete
            </CardTitle>
            <CardDescription>
              AI has extracted and categorized tax-relevant information from your documents
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6 space-y-6">
            {/* Summary */}
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <h3 className="font-semibold text-blue-900 mb-2">Summary</h3>
              <p className="text-sm text-blue-800">{analysisResult.extracted_data?.summary}</p>
            </div>

            {/* Income Details */}
            <div>
              <h3 className="font-semibold text-lg mb-3">Income Extracted</h3>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <p className="text-sm text-green-700 mb-1">Salary</p>
                  <p className="text-2xl font-bold text-green-900">
                    {formatCurrency(analysisResult.extracted_data?.income?.salary || 0)}
                  </p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <p className="text-sm text-green-700 mb-1">Business</p>
                  <p className="text-2xl font-bold text-green-900">
                    {formatCurrency(analysisResult.extracted_data?.income?.business || 0)}
                  </p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <p className="text-sm text-green-700 mb-1">Other Income</p>
                  <p className="text-2xl font-bold text-green-900">
                    {formatCurrency(analysisResult.extracted_data?.income?.other || 0)}
                  </p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Deductions */}
            <div>
              <h3 className="font-semibold text-lg mb-3">Deductions Found</h3>
              <div className="grid md:grid-cols-2 gap-3">
                {Object.entries(analysisResult.extracted_data?.deductions || {}).filter(([key]) => key !== 'details').map(([key, value]) => (
                  value > 0 && (
                    <div key={key} className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                      <p className="text-xs text-orange-700">{key.replace(/([A-Z])/g, ' $1').trim()}</p>
                      <p className="text-lg font-bold text-orange-900">{formatCurrency(value)}</p>
                    </div>
                  )
                ))}
              </div>
            </div>

            {/* TDS Paid */}
            {analysisResult.extracted_data?.tds_paid?.total > 0 && (
              <>
                <Separator />
                <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                  <h3 className="font-semibold text-purple-900 mb-2">TDS Already Paid</h3>
                  <p className="text-3xl font-bold text-purple-700">
                    {formatCurrency(analysisResult.extracted_data.tds_paid.total)}
                  </p>
                  <p className="text-sm text-purple-600 mt-1">This will be adjusted in your final tax calculation</p>
                </div>
              </>
            )}

            {/* Recommendations */}
            {analysisResult.extracted_data?.recommendations && (
              <>
                <Separator />
                <div className="p-4 bg-amber-50 rounded-lg border border-amber-200">
                  <h3 className="font-semibold text-amber-900 mb-2">Recommendations</h3>
                  <ul className="list-disc list-inside space-y-1 text-sm text-amber-800">
                    {analysisResult.extracted_data.recommendations.map((rec, index) => (
                      <li key={index}>{rec}</li>
                    ))}
                  </ul>
                </div>
              </>
            )}

            {/* Action Button */}
            <Button
              onClick={() => onAnalysisComplete && onAnalysisComplete(analysisResult)}
              className="w-full"
              size="lg"
            >
              Use This Data for Tax Calculation
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default DocumentUploadAnalyzer;
