import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { taxApi } from '../services/taxApi';
import { useToast } from '../hooks/use-toast';
import { TrendingUp, Calendar, IndianRupee, Info, Loader2 } from 'lucide-react';

const CapitalGainsCalculator = () => {
  const { toast } = useToast();
  const [assetType, setAssetType] = useState('equity');
  const [holdingPeriod, setHoldingPeriod] = useState('long');
  const [purchasePrice, setPurchasePrice] = useState('');
  const [salePrice, setSalePrice] = useState('');
  const [purchaseDate, setPurchaseDate] = useState('');
  const [saleDate, setSaleDate] = useState('');
  const [indexation, setIndexation] = useState(false);
  const [loading, setLoading] = useState(false);
  const [taxCalculation, setTaxCalculation] = useState(null);

  const gains = useMemo(() => {
    const purchase = parseFloat(purchasePrice || 0);
    const sale = parseFloat(salePrice || 0);
    return sale - purchase;
  }, [purchasePrice, salePrice]);

  const handleCalculate = async () => {
    if (!purchasePrice || !salePrice || gains <= 0) {
      toast({
        title: "Error",
        description: "Please enter valid purchase and sale prices",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const response = await taxApi.calculateCapitalGains(
        assetType,
        holdingPeriod,
        parseFloat(purchasePrice),
        parseFloat(salePrice),
        purchaseDate,
        saleDate,
        indexation
      );

      if (response.success) {
        setTaxCalculation(response.data);
        toast({
          title: "Success",
          description: "Capital gains calculated successfully"
        });
      }
    } catch (error) {
      console.error('Error calculating capital gains:', error);
      toast({
        title: "Error",
        description: "Failed to calculate capital gains. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(value);
  };

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      {/* Input Section */}
      <div className="lg:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-blue-600" />
              Capital Gains Calculator
            </CardTitle>
            <CardDescription>
              Calculate tax on sale of equity, mutual funds, property, and other capital assets
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Asset Type Selection */}
            <div className="space-y-2">
              <Label>Asset Type</Label>
              <Select value={assetType} onValueChange={setAssetType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="equity">Listed Equity/Mutual Funds</SelectItem>
                  <SelectItem value="property">Property/Real Estate</SelectItem>
                  <SelectItem value="other">Other Assets (Gold, Bonds, etc.)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Holding Period */}
            <div className="space-y-2">
              <Label>Holding Period</Label>
              <div className="grid grid-cols-2 gap-4">
                <Button
                  variant={holdingPeriod === 'short' ? 'default' : 'outline'}
                  onClick={() => setHoldingPeriod('short')}
                  className="w-full"
                >
                  <Calendar className="w-4 h-4 mr-2" />
                  Short-term
                  <Badge variant="secondary" className="ml-2">
                    {assetType === 'equity' ? '<12 months' : '<24 months'}
                  </Badge>
                </Button>
                <Button
                  variant={holdingPeriod === 'long' ? 'default' : 'outline'}
                  onClick={() => setHoldingPeriod('long')}
                  className="w-full"
                >
                  <Calendar className="w-4 h-4 mr-2" />
                  Long-term
                  <Badge variant="secondary" className="ml-2">
                    {assetType === 'equity' ? '>12 months' : '>24 months'}
                  </Badge>
                </Button>
              </div>
            </div>

            {/* Purchase & Sale Details */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="purchase-price">Purchase Price</Label>
                <Input
                  id="purchase-price"
                  type="number"
                  placeholder="0"
                  value={purchasePrice}
                  onChange={(e) => setPurchasePrice(e.target.value)}
                  className="text-lg"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="sale-price">Sale Price</Label>
                <Input
                  id="sale-price"
                  type="number"
                  placeholder="0"
                  value={salePrice}
                  onChange={(e) => setSalePrice(e.target.value)}
                  className="text-lg"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="purchase-date">Purchase Date</Label>
                <Input
                  id="purchase-date"
                  type="date"
                  value={purchaseDate}
                  onChange={(e) => setPurchaseDate(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="sale-date">Sale Date</Label>
                <Input
                  id="sale-date"
                  type="date"
                  value={saleDate}
                  onChange={(e) => setSaleDate(e.target.value)}
                />
              </div>
            </div>

            {/* Indexation Info for LTCG non-equity */}
            {assetType !== 'equity' && holdingPeriod === 'long' && (
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="flex items-start gap-3">
                  <Info className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div className="flex-1">
                    <div className="font-semibold text-blue-900 mb-1">Budget 2025 Update</div>
                    <p className="text-sm text-blue-800">
                      LTCG on property/other assets now taxed at 12.5% without indexation for assets purchased after July 23, 2024.
                      Assets purchased before this date may still claim indexation benefit if it results in lower tax.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Capital Gains Display */}
            <div className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border-2">
              <div className="flex justify-between items-center">
                <span className="font-semibold text-gray-900">Capital Gains:</span>
                <span className={`text-2xl font-bold ${gains > 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {formatCurrency(gains)}
                </span>
              </div>
            </div>

            {/* Calculate Button */}
            <Button
              onClick={handleCalculate}
              size="lg"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              disabled={!purchasePrice || !salePrice || gains <= 0 || loading}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 w-5 h-5 animate-spin" />
                  Calculating...
                </>
              ) : (
                'Calculate Capital Gains Tax'
              )}
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Results Section */}
      <div className="lg:col-span-1">
        {taxCalculation && gains > 0 ? (
          <Card className="border-2 border-blue-500 sticky top-6">
            <CardHeader className="bg-gradient-to-br from-blue-50 to-purple-50">
              <CardTitle className="flex items-center gap-2">
                <IndianRupee className="w-5 h-5" />
                Tax Calculation
              </CardTitle>
              <Badge className="w-fit">
                {holdingPeriod === 'short' ? 'Short-term' : 'Long-term'} Capital Gains
              </Badge>
            </CardHeader>
            <CardContent className="pt-6 space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Total Gains:</span>
                <span className="font-semibold text-green-600">{formatCurrency(taxCalculation.gains)}</span>
              </div>

              {taxCalculation.exemptionAmount > 0 && (
                <>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Exemption:</span>
                    <span className="font-semibold text-orange-600">- {formatCurrency(taxCalculation.exemptionAmount)}</span>
                  </div>
                  <Separator />
                </>
              )}

              <div className="flex justify-between">
                <span className="font-semibold">Taxable Gains:</span>
                <span className="font-bold">{formatCurrency(taxCalculation.taxableGain)}</span>
              </div>

              <div className="p-3 bg-gray-50 rounded-lg">
                <div className="text-sm text-gray-600 mb-1">Applicable Tax Rate:</div>
                <div className="text-xl font-bold text-blue-600">{taxCalculation.taxRate}%</div>
                {assetType !== 'equity' && holdingPeriod === 'long' && (
                  <div className="text-xs text-gray-500 mt-1">
                    {indexation ? 'With indexation benefit' : 'Without indexation'}
                  </div>
                )}
              </div>

              <Separator />

              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Base Tax:</span>
                <span>{formatCurrency(taxCalculation.baseTax)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Cess (4%):</span>
                <span>{formatCurrency(taxCalculation.cess)}</span>
              </div>

              <Separator className="my-3" />

              <div className="p-4 bg-blue-600 text-white rounded-lg">
                <div className="text-sm opacity-90 mb-1">Total Tax Payable</div>
                <div className="text-3xl font-bold">{formatCurrency(taxCalculation.totalTax)}</div>
              </div>

              <div className="p-3 bg-green-50 rounded-lg border border-green-200 mt-4">
                <div className="text-sm font-semibold text-green-900 mb-1">Net Proceeds:</div>
                <div className="text-xl font-bold text-green-700">
                  {formatCurrency(gains - taxCalculation.totalTax)}
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="border-2 border-dashed sticky top-6">
            <CardContent className="pt-6 text-center py-12">
              <TrendingUp className="w-16 h-16 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500">Enter asset details to calculate capital gains tax</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default CapitalGainsCalculator;
